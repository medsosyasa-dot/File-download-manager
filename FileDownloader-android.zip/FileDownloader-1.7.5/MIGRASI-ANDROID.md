# Catatan modernisasi (FileDownloader 1.7.5 -> Android modern)

Perubahan utama:
- Gradle 4.9-rc -> 8.7, Android Gradle Plugin 3.3-alpha -> 8.5.2 (butuh JDK 17)
- compileSdk/targetSdk 27 -> 34, minSdk 21 (library & demo)
- jcenter/bintray dihapus -> google() + mavenCentral(); publishing pakai maven-publish
- `package` di manifest dipindah ke `namespace` di build.gradle
- Support Library -> AndroidX (demo)
- Library: service foreground memakai tipe `dataSync` (wajib Android 14),
  izin FOREGROUND_SERVICE & FOREGROUND_SERVICE_DATA_SYNC, `exported=false`
- Demo: izin POST_NOTIFICATIONS (runtime, Android 13+), NotificationChannel,
  PendingIntent.FLAG_IMMUTABLE, MainActivity `exported=true`, cleartext HTTP untuk URL demo
- ThreadDebugger dihapus dari demo (dependensi lama dari jcenter)

Cara build: buka folder di Android Studio (Koala atau lebih baru) lalu Run `demo`,
atau `./gradlew :demo:assembleDebug`.
