package app.filedownloadmanager;

import java.util.ArrayList;
import java.util.List;

/** Lets the browser start downloads in the main screen without closing itself. */
final class Handoff {

    static class Request {
        String url;
        String name;
        String ua;
        String cookie;
        String referer;
        String mime;
    }

    interface Receiver {
        void onRequest(Request request);
    }

    private static Receiver receiver;
    private static final List<Request> PENDING = new ArrayList<>();

    private Handoff() {
    }

    /** Call on the main thread. Requests that arrived while no receiver existed are delivered. */
    static synchronized void setReceiver(Receiver r) {
        receiver = r;
        if (r != null && !PENDING.isEmpty()) {
            List<Request> copy = new ArrayList<>(PENDING);
            PENDING.clear();
            for (Request q : copy) r.onRequest(q);
        }
    }

    static synchronized void submit(Request request) {
        if (receiver != null) receiver.onRequest(request);
        else PENDING.add(request);
    }
}
