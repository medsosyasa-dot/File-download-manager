package app.filedownloadmanager;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * A tiny HTTP/HTTPS proxy that listens on 127.0.0.1 only. The in-app browser sends all traffic
 * through it; connections to ad and tracker hosts are refused, so those requests fail at the
 * network level (like a DNS-based blocker), and everything else is passed straight through.
 */
final class LocalProxy {

    private final ExecutorService pool = Executors.newCachedThreadPool();
    private ServerSocket server;
    private volatile boolean running;

    int start() throws IOException {
        server = new ServerSocket(0, 64, InetAddress.getByName("127.0.0.1"));
        running = true;
        pool.execute(this::acceptLoop);
        return server.getLocalPort();
    }

    void stop() {
        running = false;
        try {
            if (server != null) server.close();
        } catch (IOException ignored) {
            // closing
        }
        pool.shutdownNow();
    }

    private void acceptLoop() {
        while (running) {
            try {
                final Socket client = server.accept();
                pool.execute(() -> handle(client));
            } catch (IOException e) {
                if (!running) return;
            } catch (RuntimeException e) {
                return; // pool shut down
            }
        }
    }

    private void handle(Socket client) {
        Socket upstream = null;
        try {
            client.setSoTimeout(30_000);
            client.setTcpNoDelay(true);
            InputStream cin = client.getInputStream();
            OutputStream cout = client.getOutputStream();
            String head = readHead(cin);
            if (head == null) {
                close(client);
                return;
            }
            client.setSoTimeout(0);
            String[] lines = head.split("\r\n");
            String[] rl = lines[0].split(" ");
            if (rl.length < 3) {
                close(client);
                return;
            }
            String method = rl[0];
            String target = rl[1];

            if (method.equalsIgnoreCase("CONNECT")) {
                String host = target;
                int port = 443;
                int idx = target.lastIndexOf(':');
                if (idx > 0) {
                    host = target.substring(0, idx);
                    port = Integer.parseInt(target.substring(idx + 1));
                }
                if (host.startsWith("[") && host.endsWith("]")) {
                    host = host.substring(1, host.length() - 1);
                }
                if (AdBlocker.isHostBlocked(host)) {
                    AdBlocker.recordBlocked(host);
                    cout.write("HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n"
                            .getBytes(StandardCharsets.ISO_8859_1));
                    cout.flush();
                    close(client);
                    return;
                }
                upstream = connect(host, port);
                cout.write("HTTP/1.1 200 Connection Established\r\n\r\n"
                        .getBytes(StandardCharsets.ISO_8859_1));
                cout.flush();
            } else {
                if (!target.startsWith("http://")) {
                    close(client);
                    return;
                }
                URI u = new URI(target);
                String host = u.getHost();
                int port = u.getPort() < 0 ? 80 : u.getPort();
                if (host == null || AdBlocker.isHostBlocked(host)) {
                    AdBlocker.recordBlocked(host);
                    close(client); // no answer at all = network error for the page
                    return;
                }
                String path = u.getRawPath() == null || u.getRawPath().isEmpty()
                        ? "/" : u.getRawPath();
                if (u.getRawQuery() != null) path += "?" + u.getRawQuery();

                upstream = connect(host, port);
                StringBuilder sb = new StringBuilder();
                sb.append(method).append(' ').append(path).append(' ').append(rl[2]).append("\r\n");
                for (int i = 1; i < lines.length; i++) {
                    String line = lines[i];
                    String lower = line.toLowerCase();
                    if (line.isEmpty() || lower.startsWith("proxy-connection:")
                            || lower.startsWith("connection:") || lower.startsWith("keep-alive:")) {
                        continue;
                    }
                    sb.append(line).append("\r\n");
                }
                sb.append("Connection: close\r\n\r\n");
                OutputStream uout = upstream.getOutputStream();
                uout.write(sb.toString().getBytes(StandardCharsets.ISO_8859_1));
                uout.flush();
            }
            pipe(client, upstream);
        } catch (Exception e) {
            close(client);
            close(upstream);
        }
    }

    /**
     * Opens a connection, trying every address of the host (IPv4 first, because IPv6 is broken
     * on many networks and would otherwise cause long waits).
     */
    private static Socket connect(String host, int port) throws IOException {
        InetAddress[] addrs = InetAddress.getAllByName(host);
        java.util.Arrays.sort(addrs, (a, b) -> Boolean.compare(
                b instanceof java.net.Inet4Address, a instanceof java.net.Inet4Address));
        IOException last = null;
        for (InetAddress a : addrs) {
            Socket s = new Socket();
            try {
                s.connect(new InetSocketAddress(a, port), 6_000);
                s.setTcpNoDelay(true);
                return s;
            } catch (IOException e) {
                last = e;
                close(s);
            }
        }
        throw last != null ? last : new IOException("no address for " + host);
    }

    /** Reads the request line and headers, up to the blank line. */
    private static String readHead(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int state = 0;
        int c;
        while ((c = in.read()) >= 0) {
            sb.append((char) c);
            if (sb.length() > 65_536) return null;
            // match \r\n\r\n
            if (c == '\r' && (state == 0 || state == 2)) state++;
            else if (c == '\n' && (state == 1 || state == 3)) state++;
            else state = 0;
            if (state == 4) return sb.toString();
        }
        return null;
    }

    private void pipe(final Socket a, final Socket b) {
        final AtomicInteger finished = new AtomicInteger();
        pool.execute(() -> copy(a, b, finished));
        copy(b, a, finished);
    }

    private static void copy(Socket from, Socket to, AtomicInteger finished) {
        try {
            InputStream in = from.getInputStream();
            OutputStream out = to.getOutputStream();
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) >= 0) {
                out.write(buf, 0, n);
                out.flush();
            }
            try {
                to.shutdownOutput();
            } catch (IOException ignored) {
                // already closed
            }
            if (finished.incrementAndGet() == 2) {
                close(from);
                close(to);
            }
        } catch (IOException e) {
            close(from);
            close(to);
        }
    }

    private static void close(Socket s) {
        if (s == null) return;
        try {
            s.close();
        } catch (IOException ignored) {
            // closing
        }
    }
}
