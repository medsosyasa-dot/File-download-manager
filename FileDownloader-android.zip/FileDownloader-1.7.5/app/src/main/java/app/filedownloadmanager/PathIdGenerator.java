package app.filedownloadmanager;

import com.liulishuo.filedownloader.util.FileDownloadHelper;

/**
 * Identifies a download by its (unique) folder instead of by its link. That way a download keeps
 * its progress when the link is replaced with a fresh one after the old link expired.
 */
public class PathIdGenerator implements FileDownloadHelper.IdGenerator {

    @Override
    public int transOldId(int oldId, String url, String path, boolean pathAsDirectory) {
        return generateId(url, path, pathAsDirectory);
    }

    @Override
    public int generateId(String url, String path, boolean pathAsDirectory) {
        int id = (path + "|" + pathAsDirectory).hashCode();
        return id == 0 ? 1 : id;
    }
}
