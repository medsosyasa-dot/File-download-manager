package app.filedownloadmanager;

import android.content.Context;
import android.os.Build;
import android.text.format.Formatter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.liulishuo.filedownloader.model.FileDownloadStatus;

import java.util.List;

class DownloadAdapter extends RecyclerView.Adapter<DownloadAdapter.Holder> {

    interface Callback {
        void onAction(DownloadItem item);

        void onDelete(DownloadItem item);

        void onRename(DownloadItem item);
    }

    private final List<DownloadItem> items;
    private final Callback callback;

    DownloadAdapter(List<DownloadItem> items, Callback callback) {
        this.items = items;
        this.callback = callback;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_download, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        final DownloadItem item = items.get(position);
        Context c = h.itemView.getContext();

        h.name.setText(item.name);

        boolean unknownSize = item.total <= 0;
        if (item.isCompleted()) {
            h.progress.setIndeterminate(false);
            h.progress.setProgress(100);
        } else if (item.status == FileDownloadStatus.progress && unknownSize) {
            h.progress.setIndeterminate(true);
        } else {
            h.progress.setIndeterminate(false);
            h.progress.setProgress(unknownSize ? 0 : (int) (item.soFar * 100 / item.total));
        }

        StringBuilder info = new StringBuilder();
        if (item.isCompleted()) {
            info.append(Formatter.formatShortFileSize(c, item.total > 0 ? item.total : item.soFar));
            info.append(" • ").append(item.moving ? "Menyimpan…"
                    : item.savedUri != null ? "Tersimpan"
                    : Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ? "Belum tersimpan"
                    : "Selesai (folder aplikasi)");
            if (item.error != null && item.savedUri == null) info.append("\n").append(item.error);
        } else {
            info.append(Formatter.formatShortFileSize(c, item.soFar));
            if (!unknownSize) info.append(" / ").append(Formatter.formatShortFileSize(c, item.total));
            info.append(" • ").append(statusText(item));
            if (item.status == FileDownloadStatus.progress && item.speed > 0) {
                info.append(" • ").append(Formatter.formatShortFileSize(c, item.speed * 1024L)).append("/s");
            }
            if (item.status == FileDownloadStatus.error && item.error != null) {
                info.append("\n").append(item.error);
            }
        }
        String time = timeText(item);
        if (!time.isEmpty()) info.append("\n").append(time);
        h.info.setText(info.toString());

        boolean showSegments = !item.isCompleted() && item.segments != null
                && item.segments.length > 1;
        h.segments.setVisibility(showSegments ? View.VISIBLE : View.GONE);
        if (showSegments) h.segments.setSegments(item.segments);

        if (item.isCompleted()) {
            h.action.setText(item.savedUri != null ? "Buka" : "Simpan");
            h.action.setEnabled(!item.moving
                    && (item.savedUri != null || Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                    || Settings.treeUri(c) != null));
        } else {
            h.action.setText(item.isRunning() ? "Jeda" : item.needsNewLink() ? "Perbarui link" : "Lanjut");
            h.action.setEnabled(true);
        }
        h.action.setOnClickListener(v -> callback.onAction(item));
        h.delete.setOnClickListener(v -> callback.onDelete(item));
        h.rename.setOnClickListener(v -> callback.onRename(item));
    }

    private static String clock(long totalSeconds) {
        long h = totalSeconds / 3600;
        long m = (totalSeconds % 3600) / 60;
        long sec = totalSeconds % 60;
        return h > 0 ? String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec)
                : String.format(java.util.Locale.US, "%02d:%02d", m, sec);
    }

    private static String timeText(DownloadItem item) {
        StringBuilder sb = new StringBuilder();
        long elapsed = item.elapsedMs / 1000;
        if (item.isCompleted()) {
            if (elapsed > 0) sb.append("Selesai dalam ").append(clock(elapsed));
            return sb.toString();
        }
        if (elapsed > 0 || item.isRunning()) sb.append("Berjalan ").append(clock(elapsed));
        if (item.status == FileDownloadStatus.progress && item.speed > 0 && item.total > 0) {
            long left = (item.total - item.soFar) / (item.speed * 1024L);
            sb.append(" • Sisa ").append(clock(Math.max(0, left)));
        }
        if (item.parts > 1) sb.append(" • ").append(item.parts).append(" bagian");
        return sb.toString();
    }

    private static String statusText(DownloadItem item) {
        switch (item.status) {
            case FileDownloadStatus.pending:
            case FileDownloadStatus.started:
            case FileDownloadStatus.connected:
                return "Menunggu…";
            case FileDownloadStatus.retry:
                return "Mencoba lagi…";
            case FileDownloadStatus.progress:
                return "Mengunduh";
            case FileDownloadStatus.error:
                return "Gagal";
            default:
                return "Dijeda";
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        final TextView name;
        final TextView info;
        final ProgressBar progress;
        final MaterialButton action;
        final MaterialButton delete;
        final MaterialButton rename;
        final SegmentBar segments;

        Holder(View v) {
            super(v);
            name = v.findViewById(R.id.name);
            info = v.findViewById(R.id.info);
            progress = v.findViewById(R.id.progress);
            action = v.findViewById(R.id.action);
            delete = v.findViewById(R.id.delete);
            rename = v.findViewById(R.id.rename);
            segments = v.findViewById(R.id.segments);
        }
    }
}
