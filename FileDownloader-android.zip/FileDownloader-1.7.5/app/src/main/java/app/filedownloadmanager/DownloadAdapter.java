package app.filedownloadmanager;

import android.content.Context;
import android.os.Build;
import android.text.format.Formatter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.liulishuo.filedownloader.model.FileDownloadStatus;

import java.util.List;

class DownloadAdapter extends RecyclerView.Adapter<DownloadAdapter.Holder> {

    interface Callback {
        void onAction(DownloadItem item);

        void onDelete(DownloadItem item);
    }

    private final List<DownloadItem> items;
    private final Callback callback;

    DownloadAdapter(List<DownloadItem> items, Callback callback) {
        this.items = items;
        this.callback = callback;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_download, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        final DownloadItem item = items.get(position);
        Context c = h.itemView.getContext();

        h.name.setText(item.name);

        boolean unknownSize = item.total <= 0;
        if (item.isCompleted()) {
            h.progress.setIndeterminate(false);
            h.progress.setProgress(100);
        } else if (item.status == FileDownloadStatus.progress && unknownSize) {
            h.progress.setIndeterminate(true);
        } else {
            h.progress.setIndeterminate(false);
            h.progress.setProgress(unknownSize ? 0 : (int) (item.soFar * 100 / item.total));
        }

        StringBuilder info = new StringBuilder();
        if (item.isCompleted()) {
            info.append(Formatter.formatShortFileSize(c, item.total > 0 ? item.total : item.soFar));
            info.append(" • ").append(item.moving ? "Menyimpan ke folder Download…"
                    : item.savedUri != null ? "Tersimpan di folder Download"
                    : Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ? "Belum tersimpan di Download"
                    : "Selesai (folder aplikasi)");
            if (item.error != null && item.savedUri == null) info.append("\n").append(item.error);
        } else {
            info.append(Formatter.formatShortFileSize(c, item.soFar));
            if (!unknownSize) info.append(" / ").append(Formatter.formatShortFileSize(c, item.total));
            info.append(" • ").append(statusText(item));
            if (item.status == FileDownloadStatus.progress && item.speed > 0) {
                info.append(" • ").append(Formatter.formatShortFileSize(c, item.speed * 1024L)).append("/s");
            }
            if (item.status == FileDownloadStatus.error && item.error != null) {
                info.append("\n").append(item.error);
            }
        }
        h.info.setText(info.toString());

        if (item.isCompleted()) {
            h.action.setText(item.savedUri != null ? "Buka" : "Simpan");
            h.action.setEnabled(!item.moving
                    && (item.savedUri != null || Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q));
        } else {
            h.action.setText(item.isRunning() ? "Jeda" : "Lanjut");
            h.action.setEnabled(true);
        }
        h.action.setOnClickListener(v -> callback.onAction(item));
        h.delete.setOnClickListener(v -> callback.onDelete(item));
    }

    private static String statusText(DownloadItem item) {
        switch (item.status) {
            case FileDownloadStatus.pending:
            case FileDownloadStatus.started:
            case FileDownloadStatus.connected:
                return "Menunggu…";
            case FileDownloadStatus.retry:
                return "Mencoba lagi…";
            case FileDownloadStatus.progress:
                return "Mengunduh";
            case FileDownloadStatus.error:
                return "Gagal";
            default:
                return "Dijeda";
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        final TextView name;
        final TextView info;
        final ProgressBar progress;
        final MaterialButton action;
        final MaterialButton delete;

        Holder(View v) {
            super(v);
            name = v.findViewById(R.id.name);
            info = v.findViewById(R.id.info);
            progress = v.findViewById(R.id.progress);
            action = v.findViewById(R.id.action);
            delete = v.findViewById(R.id.delete);
        }
    }
}
