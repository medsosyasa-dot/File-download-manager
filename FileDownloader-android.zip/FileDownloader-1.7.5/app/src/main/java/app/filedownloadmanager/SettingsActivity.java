package app.filedownloadmanager;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.provider.DocumentFile;

import com.google.android.material.slider.Slider;

public class SettingsActivity extends AppCompatActivity {

    private TextView folderLabel;
    private TextView connLabel;
    private TextView connHint;

    private final ActivityResultLauncher<Uri> folderPicker = registerForActivityResult(
            new ActivityResultContracts.OpenDocumentTree(), uri -> {
                if (uri == null) return;
                try {
                    getContentResolver().takePersistableUriPermission(uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                } catch (SecurityException e) {
                    Toast.makeText(this, "Folder ini tidak bisa dipakai, pilih folder lain",
                            Toast.LENGTH_LONG).show();
                    return;
                }
                Settings.setTreeUri(this, uri.toString());
                showFolder();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        folderLabel = findViewById(R.id.folder_label);
        connLabel = findViewById(R.id.conn_label);
        connHint = findViewById(R.id.conn_hint);

        findViewById(R.id.pick_folder).setOnClickListener(v -> folderPicker.launch(null));
        findViewById(R.id.reset_folder).setOnClickListener(v -> {
            Settings.setTreeUri(this, null);
            showFolder();
        });

        com.google.android.material.switchmaterial.SwitchMaterial adBlock =
                findViewById(R.id.adblock);
        adBlock.setChecked(Settings.adBlock(this));
        adBlock.setOnCheckedChangeListener((b, checked) -> Settings.setAdBlock(this, checked));

        Slider slider = findViewById(R.id.slider);
        slider.setValue(Settings.connections(this));
        slider.addOnChangeListener((s, value, fromUser) -> {
            Settings.setConnections(this, (int) value);
            showConnections((int) value);
        });

        showFolder();
        showConnections(Settings.connections(this));
    }

    private void showFolder() {
        String tree = Settings.treeUri(this);
        if (tree == null) {
            folderLabel.setText("Folder Download (bawaan)");
            return;
        }
        DocumentFile doc = DocumentFile.fromTreeUri(this, Uri.parse(tree));
        String name = doc == null ? null : doc.getName();
        folderLabel.setText(name == null ? "Folder pilihanmu" : name);
    }

    private void showConnections(int n) {
        connLabel.setText(n + " bagian");
        StringBuilder hint = new StringBuilder(
                "Berlaku untuk download baru. Setiap bagian minimal sekitar 1 MB, "
                        + "jadi file kecil memakai lebih sedikit bagian. "
                        + "Server harus mendukung download terbagi; kalau tidak, "
                        + "otomatis memakai 1 koneksi.");
        if (n > 32) {
            hint.append("\n\nNilai di atas 32 sering ditolak atau dibatasi server "
                    + "(error 403/429) dan bisa membuat download lebih tidak stabil. "
                    + "Kalau gagal, turunkan ke 8–16.");
        }
        connHint.setText(hint.toString());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
