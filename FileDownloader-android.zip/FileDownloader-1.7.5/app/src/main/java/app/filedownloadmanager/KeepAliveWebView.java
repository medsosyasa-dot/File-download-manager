package app.filedownloadmanager;

import android.content.Context;
import android.view.View;
import android.webkit.WebView;

/**
 * A WebView that is never told its window was hidden. Without this, the web engine pauses video
 * (and its sound) as soon as the app is minimised; with it, playback continues in the background.
 */
class KeepAliveWebView extends WebView {

    KeepAliveWebView(Context context) {
        super(context);
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        if (visibility != View.VISIBLE && Settings.bgPlay(getContext())) {
            super.onWindowVisibilityChanged(View.VISIBLE);
            return;
        }
        super.onWindowVisibilityChanged(visibility);
    }
}
