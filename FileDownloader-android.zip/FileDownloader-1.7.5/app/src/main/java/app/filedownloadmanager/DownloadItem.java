package app.filedownloadmanager;

import com.liulishuo.filedownloader.model.FileDownloadStatus;

import org.json.JSONException;
import org.json.JSONObject;

class DownloadItem {
    int id;
    String url;
    String name;
    String path;
    String savedUri;
    long soFar;
    long total;
    int speed;
    byte status = FileDownloadStatus.paused;
    String error;
    boolean moving;

    boolean isRunning() {
        return status == FileDownloadStatus.pending
                || status == FileDownloadStatus.started
                || status == FileDownloadStatus.connected
                || status == FileDownloadStatus.progress
                || status == FileDownloadStatus.retry;
    }

    boolean isCompleted() {
        return status == FileDownloadStatus.completed;
    }

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("url", url);
        o.put("name", name);
        o.put("path", path);
        o.put("savedUri", savedUri == null ? JSONObject.NULL : savedUri);
        o.put("soFar", soFar);
        o.put("total", total);
        o.put("completed", isCompleted());
        return o;
    }

    static DownloadItem fromJson(JSONObject o) throws JSONException {
        DownloadItem i = new DownloadItem();
        i.id = o.getInt("id");
        i.url = o.getString("url");
        i.name = o.getString("name");
        i.path = o.getString("path");
        i.savedUri = o.isNull("savedUri") ? null : o.getString("savedUri");
        i.soFar = o.optLong("soFar");
        i.total = o.optLong("total");
        // Anything not finished is shown as paused after the app restarts.
        i.status = o.optBoolean("completed")
                ? FileDownloadStatus.completed : FileDownloadStatus.paused;
        return i;
    }
}
