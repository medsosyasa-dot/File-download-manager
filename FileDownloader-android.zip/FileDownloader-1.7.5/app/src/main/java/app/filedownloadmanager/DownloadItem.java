package app.filedownloadmanager;

import com.liulishuo.filedownloader.model.FileDownloadStatus;

import org.json.JSONException;
import org.json.JSONObject;

class DownloadItem {
    int id;
    String url;
    String name;
    String path;
    String savedUri;
    String targetPath;
    String mime;
    long soFar;
    long total;
    int speed;
    byte status = FileDownloadStatus.paused;
    String error;
    boolean moving;
    // request details (from the in-app browser) so protected links keep working
    String userAgent;
    String cookie;
    String referer;
    // set when the user typed/renamed the name: never overwrite it with the server's name
    boolean customName;
    // fixed file name on disk when the user chose the name before downloading
    String diskName;
    long elapsedMs;
    // not persisted
    long lastTick;
    float[] segments;
    int parts;

    boolean isRunning() {
        return status == FileDownloadStatus.pending
                || status == FileDownloadStatus.started
                || status == FileDownloadStatus.connected
                || status == FileDownloadStatus.progress
                || status == FileDownloadStatus.retry;
    }

    boolean isCompleted() {
        return status == FileDownloadStatus.completed;
    }

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("url", url);
        o.put("name", name);
        o.put("path", path);
        o.put("savedUri", savedUri == null ? JSONObject.NULL : savedUri);
        o.put("targetPath", targetPath == null ? JSONObject.NULL : targetPath);
        o.put("mime", mime == null ? JSONObject.NULL : mime);
        o.put("ua", userAgent == null ? JSONObject.NULL : userAgent);
        o.put("cookie", cookie == null ? JSONObject.NULL : cookie);
        o.put("referer", referer == null ? JSONObject.NULL : referer);
        o.put("customName", customName);
        o.put("diskName", diskName == null ? JSONObject.NULL : diskName);
        o.put("elapsedMs", elapsedMs);
        o.put("soFar", soFar);
        o.put("total", total);
        o.put("completed", isCompleted());
        return o;
    }

    static DownloadItem fromJson(JSONObject o) throws JSONException {
        DownloadItem i = new DownloadItem();
        i.id = o.getInt("id");
        i.url = o.getString("url");
        i.name = o.getString("name");
        i.path = o.getString("path");
        i.savedUri = o.isNull("savedUri") ? null : o.getString("savedUri");
        i.targetPath = o.isNull("targetPath") ? null : o.optString("targetPath", null);
        i.mime = o.isNull("mime") ? null : o.optString("mime", null);
        i.userAgent = o.isNull("ua") ? null : o.optString("ua", null);
        i.cookie = o.isNull("cookie") ? null : o.optString("cookie", null);
        i.referer = o.isNull("referer") ? null : o.optString("referer", null);
        i.customName = o.optBoolean("customName");
        i.diskName = o.isNull("diskName") ? null : o.optString("diskName", null);
        i.elapsedMs = o.optLong("elapsedMs");
        i.soFar = o.optLong("soFar");
        i.total = o.optLong("total");
        // Anything not finished is shown as paused after the app restarts.
        i.status = o.optBoolean("completed")
                ? FileDownloadStatus.completed : FileDownloadStatus.paused;
        return i;
    }
}
