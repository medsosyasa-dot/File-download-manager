package app.filedownloadmanager;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.FrameLayout;

/** A frame that tells a listener whenever the screen is touched, without taking the touch. */
public class WatchFrameLayout extends FrameLayout {

    public interface TouchListener {
        void onTouched();
    }

    private TouchListener listener;

    public WatchFrameLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    void setTouchListener(TouchListener l) {
        listener = l;
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (listener != null && ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
            listener.onTouched();
        }
        return super.dispatchTouchEvent(ev);
    }
}
