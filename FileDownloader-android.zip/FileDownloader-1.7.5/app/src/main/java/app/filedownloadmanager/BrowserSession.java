package app.filedownloadmanager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.MutableContextWrapper;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

/**
 * Keeps the browser's tabs alive for as long as the app process lives, so leaving the browser
 * screen and coming back does not reload anything. Web views use a context wrapper that is
 * pointed at the visible browser screen while there is one.
 */
final class BrowserSession {

    interface Host {
        /** Tab list, current tab or tab count changed. */
        void onTabsChanged();

        /** Title, address or icon of a tab changed. */
        void onTabUpdated(BrowserTab tab);

        void onProgress(BrowserTab tab, int percent);

        void onMediaChanged(BrowserTab tab);

        void confirmNewWindow(BrowserTab tab, String url);

        void confirmRedirect(BrowserTab tab, String url);

        void deliver(Handoff.Request request);

        /** A page wants to show its video full screen. */
        void onShowCustomView(View view, WebChromeClient.CustomViewCallback callback);

        void onHideCustomView();
    }

    static final String HOME = "https://www.google.com";
    private static final int MAX_LIVE_TABS = 8;
    private static final String PREFS = "browser";
    private static final Pattern MEDIA_PATH = Pattern.compile(
            "\\.(mp4|webm|mkv|m4v|mov|flv|3gp|mp3|m4a|aac|ogg|wav)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern STREAM_PATH = Pattern.compile(
            "\\.(m3u8|mpd)$", Pattern.CASE_INSENSITIVE);

    private static BrowserSession instance;

    static synchronized BrowserSession get(Context c) {
        if (instance == null) instance = new BrowserSession(c.getApplicationContext());
        return instance;
    }

    final Context app;
    final List<BrowserTab> tabs = new ArrayList<>();
    BrowserTab current;
    Host host;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private Activity activity;
    private boolean started;
    private boolean adBlock;
    private String adScript;
    private String earlyScript;
    private String mediaScript;
    private boolean documentStart;
    private LocalProxy proxy;
    private volatile boolean proxyActive;
    private String webUa;
    private String siteScript;
    private String pickScript;
    private String wideScript;
    private boolean fullscreenActive;
    private boolean playingAny;
    private long lastBlockToast;
    private final Set<String> strictSites = Collections.synchronizedSet(new HashSet<String>());
    private final Map<String, Set<String>> elementRules = new ConcurrentHashMap<>();

    private BrowserSession(Context app) {
        this.app = app;
        loadSiteRules();
    }

    // ------------------------------------------------------------ lifecycle

    /** Prepares scripts and the blocking proxy once per process, then calls {@code ready}. */
    void start(final Runnable ready) {
        if (started) {
            ready.run();
            return;
        }
        started = true;
        adBlock = Settings.adBlock(app);
        earlyScript = readAsset("early.js");
        mediaScript = readAsset("media.js");
        siteScript = readAsset("site.js");
        pickScript = readAsset("pick.js");
        wideScript = readAsset("wide.js");
        documentStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        if (adBlock) {
            AdBlocker.ensureLoaded(app);
            adScript = readAsset("adblock.js");
            if (startProxy(ready)) return;
        }
        ready.run();
    }

    /** Called by the browser screen: web views now draw into this activity. */
    void attach(Activity a) {
        activity = a;
        for (BrowserTab t : tabs) setBase(t, a);
    }

    void detach(Host h) {
        if (host == h) host = null;
        activity = null;
        for (BrowserTab t : tabs) setBase(t, app);
    }

    private void setBase(BrowserTab t, Context c) {
        if (t.web != null && t.web.getContext() instanceof MutableContextWrapper) {
            ((MutableContextWrapper) t.web.getContext()).setBaseContext(c);
        }
    }

    void pause() {
        for (BrowserTab t : tabs) if (t.web != null) t.web.onPause();
    }

    void resume() {
        if (current != null && current.web != null) current.web.onResume();
    }

    /** Closes every tab and stops the proxy ("Keluar"). */
    void closeAll() {
        for (BrowserTab t : new ArrayList<>(tabs)) destroyWeb(t);
        tabs.clear();
        current = null;
        if (proxy != null) {
            proxyActive = false;
            try {
                ProxyController.getInstance().clearProxyOverride(
                        ContextCompat.getMainExecutor(app), () -> { });
            } catch (Exception ignored) {
                // not supported / already cleared
            }
            proxy.stop();
            proxy = null;
        }
        playingAny = false;
        PlaybackService.stop(app);
        started = false;
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove("tabs").remove("current").apply();
    }

    // ---------------------------------------------------------------- tabs

    /** Brings back the tabs saved by an earlier run; only the current one is loaded. */
    void restoreIfNeeded() {
        if (!tabs.isEmpty()) return;
        try {
            String s = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getString("tabs", null);
            if (s == null) return;
            JSONArray a = new JSONArray(s);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                BrowserTab t = new BrowserTab();
                t.url = o.optString("url");
                t.title = o.optString("title");
                t.locked = o.optBoolean("locked");
                tabs.add(t);
            }
            int idx = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("current", 0);
            if (!tabs.isEmpty()) select(tabs.get(Math.max(0, Math.min(idx, tabs.size() - 1))));
        } catch (Exception ignored) {
            // start with no tabs
        }
    }

    BrowserTab openTab(String url) {
        BrowserTab t = new BrowserTab();
        t.url = url;
        tabs.add(t);
        select(t);
        return t;
    }

    void select(BrowserTab tab) {
        ensureWeb(tab);
        current = tab;
        tab.lastUsed = System.currentTimeMillis();
        for (BrowserTab t : tabs) {
            if (t.web == null) continue;
            if (t == tab) t.web.onResume();
            else t.web.onPause();
        }
        evict();
        if (host != null) host.onTabsChanged();
        save();
    }

    /** Closes a tab. Returns false when nothing was closed (unknown or locked tab). */
    boolean close(BrowserTab tab) {
        int index = tabs.indexOf(tab);
        if (index < 0 || tab.locked) return false;
        tabs.remove(tab);
        destroyWeb(tab);
        if (tabs.isEmpty()) {
            current = null;
            if (host != null) host.onTabsChanged();
        } else if (tab == current) {
            select(tabs.get(Math.max(0, Math.min(index, tabs.size()) - 1)));
        } else if (host != null) {
            host.onTabsChanged();
        }
        save();
        return true;
    }

    int lockedCount() {
        int n = 0;
        for (BrowserTab t : tabs) if (t.locked) n++;
        return n;
    }

    void toggleLock(BrowserTab tab) {
        tab.locked = !tab.locked;
        save();
        if (host != null) host.onTabUpdated(tab);
    }

    /**
     * Closes every tab that is not locked. When no locked tab is left, the browser is shut down
     * completely. Returns how many tabs remain.
     */
    int closeUnlocked() {
        for (BrowserTab t : new ArrayList<>(tabs)) {
            if (!t.locked) {
                tabs.remove(t);
                destroyWeb(t);
            }
        }
        if (tabs.isEmpty()) {
            closeAll();
            return 0;
        }
        if (current == null || !tabs.contains(current)) current = tabs.get(tabs.size() - 1);
        select(current);
        return tabs.size();
    }

    void openPending(BrowserTab tab, String url) {
        tab.pendingNewWindow = false;
        tab.fromPopup = true;
        tab.url = url;
        tabs.add(tab);
        select(tab);
        tab.web.loadUrl(url);
    }

    void destroyPending(BrowserTab tab) {
        destroyWeb(tab);
    }

    private void ensureWeb(BrowserTab tab) {
        if (tab.web != null) return;
        createWeb(tab);
        if (!tab.url.isEmpty()) tab.web.loadUrl(tab.url);
    }

    /** Frees the oldest unused web views (locked tabs last); those tabs reload when opened. */
    private void evict() {
        while (true) {
            int live = 0;
            BrowserTab oldest = null;
            BrowserTab oldestLocked = null;
            for (BrowserTab t : tabs) {
                if (t.web == null) continue;
                live++;
                if (t == current) continue;
                if (t.locked) {
                    if (oldestLocked == null || t.lastUsed < oldestLocked.lastUsed) oldestLocked = t;
                } else if (oldest == null || t.lastUsed < oldest.lastUsed) {
                    oldest = t;
                }
            }
            if (live <= MAX_LIVE_TABS) return;
            BrowserTab victim = oldest != null ? oldest : oldestLocked;
            if (victim == null) return;
            destroyWeb(victim);
        }
    }

    private void destroyWeb(BrowserTab t) {
        WebView w = t.web;
        t.web = null;
        if (t.playing) {
            t.playing = false;
            recomputePlaying();
        }
        if (w == null) return;
        try {
            w.stopLoading();
            if (w.getParent() instanceof android.view.ViewGroup) {
                ((android.view.ViewGroup) w.getParent()).removeView(w);
            }
            w.destroy();
        } catch (Exception ignored) {
            // already destroyed
        }
    }

    void save() {
        try {
            JSONArray a = new JSONArray();
            for (BrowserTab t : tabs) {
                JSONObject o = new JSONObject();
                o.put("url", t.url);
                o.put("title", t.title);
                o.put("locked", t.locked);
                a.put(o);
            }
            app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString("tabs", a.toString())
                    .putInt("current", Math.max(0, tabs.indexOf(current)))
                    .apply();
        } catch (Exception ignored) {
            // not critical
        }
    }

    // ------------------------------------------------------------ web views

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void createWeb(final BrowserTab tab) {
        MutableContextWrapper ctx = new MutableContextWrapper(app);
        if (activity != null) ctx.setBaseContext(activity);
        WebView web = new WebView(ctx);
        tab.web = web;

        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        ws.setSupportMultipleWindows(true);
        ws.setJavaScriptCanOpenWindowsAutomatically(true);
        // Look like a normal mobile browser rather than an embedded WebView.
        ws.setUserAgentString(ws.getUserAgentString().replace("; wv", ""));
        webUa = ws.getUserAgentString();

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new MediaBridge(tab), "FdmMedia");
        if (documentStart) {
            if (earlyScript != null) {
                WebViewCompat.addDocumentStartJavaScript(web, earlyScript,
                        Collections.singleton("*"));
            }
            if (siteScript != null) {
                WebViewCompat.addDocumentStartJavaScript(web, siteScript,
                        Collections.singleton("*"));
            }
            if (wideScript != null) {
                WebViewCompat.addDocumentStartJavaScript(web, wideScript,
                        Collections.singleton("*"));
            }
            if (adBlock && adScript != null) {
                WebViewCompat.addDocumentStartJavaScript(web, adScript,
                        Collections.singleton("*"));
            }
        }

        web.setWebViewClient(new TabClient(tab));
        web.setWebChromeClient(new TabChrome(tab));
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, length) -> {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
                Toast.makeText(app, "Link download ini tidak didukung", Toast.LENGTH_SHORT).show();
                return;
            }
            Handoff.Request r = new Handoff.Request();
            r.url = url;
            r.ua = userAgent;
            r.cookie = CookieManager.getInstance().getCookie(url);
            r.referer = tab.url;
            r.mime = mimeType;
            r.name = URLUtil.guessFileName(url, contentDisposition, mimeType);
            deliver(r);
        });
    }

    void deliver(Handoff.Request r) {
        if (host != null) host.deliver(r);
        else {
            Handoff.submit(r);
            Toast.makeText(app, "Download ditambahkan: " + r.name, Toast.LENGTH_SHORT).show();
        }
    }

    String userAgent() {
        return webUa;
    }

    // ----------------------------------------------------------- media / DRM

    static boolean isStream(String url) {
        String path = Uri.parse(url).getPath();
        return path != null && STREAM_PATH.matcher(path).find();
    }

    static boolean isDrmLabel(String label) {
        return label != null && !label.isEmpty() && !label.startsWith("AES-128");
    }

    private void addMedia(BrowserTab tab, String url) {
        if (tab.mediaSet.size() >= 100 || !tab.mediaSet.add(url)) return;
        tab.media.add(url);
        if (host != null) host.onMediaChanged(tab);
    }

    private void markDrm(BrowserTab tab, String keySystem) {
        String k = keySystem == null ? "" : keySystem.toLowerCase(Locale.ROOT);
        String name = k.contains("widevine") ? "Widevine"
                : k.contains("playready") ? "PlayReady"
                : k.contains("fairplay") || k.contains("apple") ? "FairPlay"
                : k.contains("clearkey") ? "ClearKey" : "DRM";
        if (tab.drm == null) {
            tab.drm = name;
            if (host != null) host.onMediaChanged(tab);
        }
    }

    interface StreamResult {
        void done(String label);
    }

    /**
     * Looks inside a stream manifest for encryption / DRM markers (best effort). Only done when
     * the user asks, so pages are not hit with extra requests while they play.
     */
    void inspectStream(final BrowserTab tab, final String url, final StreamResult cb) {
        String known = tab.mediaInfo.get(url);
        if (known != null) {
            cb.done(known);
            return;
        }
        final String referer = tab.url;
        final String cookie = CookieManager.getInstance().getCookie(url);
        final String ua = webUa;
        io.execute(() -> {
            String label = null;
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(10_000);
                c.setReadTimeout(10_000);
                if (ua != null) c.setRequestProperty("User-Agent", ua);
                if (cookie != null) c.setRequestProperty("Cookie", cookie);
                if (!referer.isEmpty()) c.setRequestProperty("Referer", referer);
                if (c.getResponseCode() == 200) {
                    InputStream in = c.getInputStream();
                    byte[] buf = new byte[64 * 1024];
                    int n = 0;
                    int r;
                    while (n < buf.length && (r = in.read(buf, n, buf.length - n)) > 0) n += r;
                    label = analyze(new String(buf, 0, n, StandardCharsets.UTF_8));
                }
                c.disconnect();
            } catch (Exception ignored) {
                // leave as unknown
            }
            final String result = label == null ? "" : label;
            handler.post(() -> {
                tab.mediaInfo.put(url, result);
                if (isDrmLabel(result) && tab.drm == null) tab.drm = result;
                if (host != null) host.onMediaChanged(tab);
                cb.done(result);
            });
        });
    }

    private static String analyze(String body) {
        String s = body.toLowerCase(Locale.ROOT);
        if (s.contains("<contentprotection")) {
            if (s.contains("edef8ba9-79d6-4ace-a3c8-27dcd51d21ed") || s.contains("widevine")) {
                return "Widevine";
            }
            if (s.contains("9a04f079-9840-4286-ab92-e65be0885f95") || s.contains("playready")) {
                return "PlayReady";
            }
            if (s.contains("94ce86fb-07ff-4f43-adb8-93d2fa968ca2") || s.contains("fairplay")) {
                return "FairPlay";
            }
            return "DRM";
        }
        if (s.contains("#ext-x-key") || s.contains("#ext-x-session-key")) {
            if (s.contains("com.apple.streamingkeydelivery") || s.contains("fairplay")) {
                return "FairPlay";
            }
            if (s.contains("widevine") || s.contains("edef8ba9")) return "Widevine";
            if (s.contains("playready")) return "PlayReady";
            if (s.contains("method=sample-aes")) return "SAMPLE-AES (DRM)";
            if (s.contains("method=aes-128")) return "AES-128 (terenkripsi)";
        }
        return null;
    }

    /** Receives findings from the page scripts (runs on a background thread). */
    private class MediaBridge {
        private final BrowserTab tab;

        MediaBridge(BrowserTab tab) {
            this.tab = tab;
        }

        @JavascriptInterface
        public void found(final String url) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
            handler.post(() -> addMedia(tab, url));
        }

        @JavascriptInterface
        public void playing(final boolean on) {
            handler.post(() -> setPlaying(tab, on));
        }

        @JavascriptInterface
        public boolean wide() {
            return wideNow();
        }

        @JavascriptInterface
        public boolean bgPlay() {
            return Settings.bgPlay(app);
        }

        @JavascriptInterface
        public String rules(String host) {
            return rulesJson(host == null ? "" : host);
        }

        @JavascriptInterface
        public void blockElement(final String host, final String selector) {
            handler.post(() -> addElementRule(host, selector));
        }

        @JavascriptInterface
        public void drm(final String keySystem) {
            handler.post(() -> markDrm(tab, keySystem));
        }
    }

    // ------------------------------------------------------ web clients

    private class TabClient extends WebViewClient {
        private final BrowserTab tab;

        TabClient(BrowserTab tab) {
            this.tab = tab;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            if (adBlock) {
                // With the local proxy active, blocked hosts are refused by the proxy so the
                // page sees a real network error; otherwise answer them here.
                boolean script = AdBlocker.isAdScript(u) || AdBlocker.isYoutubeAdPath(u);
                boolean hostBlocked = !proxyActive && AdBlocker.isHostBlocked(u.getHost());
                if (script || hostBlocked) {
                    AdBlocker.recordBlocked(script && u.getPath() != null
                            ? u.getHost() + u.getPath() : u.getHost());
                    return new WebResourceResponse("text/plain", "utf-8", 404, "Blocked",
                            new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
                }
            }
            if ("GET".equalsIgnoreCase(request.getMethod())) {
                String path = u.getPath();
                if (path != null && (MEDIA_PATH.matcher(path).find()
                        || STREAM_PATH.matcher(path).find())) {
                    final String s = u.toString();
                    handler.post(() -> addMedia(tab, s));
                }
            }
            return super.shouldInterceptRequest(view, request);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            String scheme = u.getScheme();
            // Stay inside the browser; ignore intent:, market: and similar links.
            if (!("http".equals(scheme) || "https".equals(scheme))) return true;
            if (adBlock && AdBlocker.shouldBlock(u)) return true;
            if (tab.pendingNewWindow) {
                confirmNewWindow(tab, u.toString());
                return true;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N
                    && request.isForMainFrame() && !request.hasGesture() && !request.isRedirect()
                    && !tab.url.isEmpty()
                    && !siteOf(tab.url).equals(siteOf(u.toString()))) {
                // A page moving itself to another site without any tap: ask first.
                if (isStrict(tab.url)) {
                    noteBlocked();
                } else if (host != null) {
                    host.confirmRedirect(tab, u.toString());
                }
                return true;
            }
            return false;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            if (tab.pendingNewWindow) {
                if (url != null && url.startsWith("http")) {
                    view.stopLoading();
                    confirmNewWindow(tab, url);
                }
                return;
            }
            tab.url = url == null ? "" : url;
            tab.pageStartedAt = System.currentTimeMillis();
            tab.media.clear();
            tab.mediaSet.clear();
            tab.mediaInfo.clear();
            tab.drm = null;
            if (host != null) {
                host.onTabUpdated(tab);
                host.onMediaChanged(tab);
            }
            // Older WebView versions: inject the scripts late instead.
            if (!documentStart) {
                if (earlyScript != null) view.evaluateJavascript(earlyScript, null);
                if (siteScript != null) view.evaluateJavascript(siteScript, null);
                if (wideScript != null) view.evaluateJavascript(wideScript, null);
                if (adBlock && adScript != null) view.evaluateJavascript(adScript, null);
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (mediaScript != null && !tab.pendingNewWindow) {
                view.evaluateJavascript(mediaScript, null);
            }
            save();
        }
    }

    private class TabChrome extends WebChromeClient {
        private final BrowserTab tab;

        TabChrome(BrowserTab tab) {
            this.tab = tab;
        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            if (host != null) host.onProgress(tab, newProgress);
        }

        @Override
        public void onReceivedTitle(WebView view, String title) {
            tab.title = title == null ? "" : title;
            if (host != null) host.onTabUpdated(tab);
        }

        @Override
        public void onReceivedIcon(WebView view, Bitmap icon) {
            tab.icon = icon;
            if (host != null) host.onTabUpdated(tab);
        }

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                      Message resultMsg) {
            final BrowserTab nt = new BrowserTab();
            nt.pendingNewWindow = true;
            nt.userGesture = isUserGesture;
            nt.parentUrl = tab.url;
            createWeb(nt);
            WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
            transport.setWebView(nt.web);
            resultMsg.sendToTarget();
            // If the new window never navigates anywhere, drop it.
            handler.postDelayed(() -> {
                if (nt.pendingNewWindow && !nt.asked) destroyPending(nt);
            }, 20_000);
            return true;
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (host != null) host.onShowCustomView(view, callback);
            else callback.onCustomViewHidden();
        }

        @Override
        public void onHideCustomView() {
            if (host != null) host.onHideCustomView();
        }

        @Override
        public void onCloseWindow(WebView window) {
            if (!tab.pendingNewWindow) close(tab);
        }
    }

    /** A page asked for a new window: ask before opening, unless it is a plain same-site link. */
    private void confirmNewWindow(BrowserTab tab, String url) {
        if (tab.asked) return;
        tab.asked = true;
        if (adBlock && AdBlocker.shouldBlock(Uri.parse(url))) {
            destroyPending(tab);
            return;
        }
        if (tab.userGesture && siteOf(tab.parentUrl).equals(siteOf(url))) {
            openPending(tab, url);
            return;
        }
        if (isStrict(tab.parentUrl)) {
            destroyPending(tab);
            noteBlocked();
            return;
        }
        if (host == null) {
            destroyPending(tab);
            return;
        }
        host.confirmNewWindow(tab, url);
    }

    /** Rough "same website" key: the last two host labels (three for names like example.co.id). */
    static String siteOf(String url) {
        String host = Uri.parse(url == null ? "" : url).getHost();
        if (host == null) return "";
        String[] p = host.toLowerCase(Locale.ROOT).split("\\.");
        int n = p.length;
        if (n >= 3 && p[n - 1].length() == 2 && p[n - 2].length() <= 3) {
            return p[n - 3] + "." + p[n - 2] + "." + p[n - 1];
        }
        return n >= 2 ? p[n - 2] + "." + p[n - 1] : host;
    }

    // ------------------------------------------- full screen "wide" and background sound

    boolean wideNow() {
        return fullscreenActive && Settings.wide(app);
    }

    void setFullscreen(boolean on) {
        fullscreenActive = on;
        pushWide();
    }

    /** Tells the page (and its frames) whether to fill the screen by cropping the video. */
    void pushWide() {
        if (current != null && current.web != null) {
            current.web.evaluateJavascript(
                    "window.__fdmSetWide&&window.__fdmSetWide(" + wideNow() + ")", null);
        }
    }

    private void setPlaying(BrowserTab tab, boolean on) {
        tab.playing = on;
        recomputePlaying();
    }

    private void recomputePlaying() {
        boolean any = false;
        for (BrowserTab t : tabs) if (t.playing) any = true;
        if (any == playingAny) return;
        playingAny = any;
        if (!Settings.bgPlay(app)) return;
        if (any) PlaybackService.start(app);
        else PlaybackService.stop(app);
    }

    /** Pauses everything that is playing (used by the notification's Pause button). */
    void pauseMedia() {
        for (BrowserTab t : tabs) {
            if (t.web != null) {
                t.web.evaluateJavascript(
                        "document.querySelectorAll('video,audio').forEach(function(v){v.pause();})",
                        null);
            }
        }
    }

    // ------------------------------------------------ per-site ad rules

    boolean isStrict(String url) {
        return strictSites.contains(siteOf(url));
    }

    void setStrict(String site, boolean on) {
        if (on) strictSites.add(site);
        else strictSites.remove(site);
        saveSiteRules();
        applySiteScript();
    }

    /** Runs the site rules again on the page that is open right now. */
    private void applySiteScript() {
        if (current != null && current.web != null && siteScript != null) {
            current.web.evaluateJavascript("window.__fdmSite=false;" + siteScript, null);
        }
    }

    /** Lets the user tap an ad on the current page to block it. */
    void startPicker() {
        if (current != null && current.web != null && pickScript != null) {
            current.web.evaluateJavascript("window.__fdmPicking=false;" + pickScript, null);
        }
    }

    String rulesJson(String host) {
        String site = siteOf("https://" + host);
        JSONArray sel = new JSONArray();
        Set<String> set = elementRules.get(site);
        if (set != null) {
            synchronized (set) {
                for (String s : set) sel.put(s);
            }
        }
        JSONObject o = new JSONObject();
        try {
            o.put("strict", strictSites.contains(site));
            o.put("sel", sel);
        } catch (Exception ignored) {
            // empty rules
        }
        return o.toString();
    }

    private void addElementRule(String host, String selector) {
        if (host == null || selector == null || selector.isEmpty() || selector.length() > 300) return;
        String site = siteOf("https://" + host);
        Set<String> set = elementRules.get(site);
        if (set == null) {
            set = Collections.synchronizedSet(new LinkedHashSet<String>());
            elementRules.put(site, set);
        }
        set.add(selector);
        saveSiteRules();
        Toast.makeText(app, "Elemen diblokir untuk " + site, Toast.LENGTH_SHORT).show();
    }

    void clearSiteRules() {
        strictSites.clear();
        elementRules.clear();
        saveSiteRules();
    }

    private void noteBlocked() {
        long now = System.currentTimeMillis();
        if (now - lastBlockToast > 3000) {
            lastBlockToast = now;
            Toast.makeText(app, "Pop-up diblokir", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadSiteRules() {
        SharedPreferences sp = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> strict = sp.getStringSet("strict", null);
        if (strict != null) strictSites.addAll(strict);
        String json = sp.getString("elemrules", null);
        if (json == null) return;
        try {
            JSONObject o = new JSONObject(json);
            Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                JSONArray a = o.getJSONArray(k);
                Set<String> set = Collections.synchronizedSet(new LinkedHashSet<String>());
                for (int i = 0; i < a.length(); i++) set.add(a.getString(i));
                elementRules.put(k, set);
            }
        } catch (Exception ignored) {
            // start without element rules
        }
    }

    private void saveSiteRules() {
        try {
            JSONObject o = new JSONObject();
            for (Map.Entry<String, Set<String>> en : elementRules.entrySet()) {
                JSONArray a = new JSONArray();
                synchronized (en.getValue()) {
                    for (String s : en.getValue()) a.put(s);
                }
                o.put(en.getKey(), a);
            }
            Set<String> copy;
            synchronized (strictSites) {
                copy = new HashSet<>(strictSites);
            }
            app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putStringSet("strict", copy)
                    .putString("elemrules", o.toString())
                    .apply();
        } catch (Exception ignored) {
            // not critical
        }
    }

    // ------------------------------------------------------ proxy and assets

    /** Routes the browser through the local blocking proxy; returns false if not possible. */
    private boolean startProxy(final Runnable ready) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return false;
        try {
            proxy = new LocalProxy();
            int port = proxy.start();
            ProxyConfig config = new ProxyConfig.Builder()
                    .addProxyRule("127.0.0.1:" + port)
                    .build();
            ProxyController.getInstance().setProxyOverride(config,
                    ContextCompat.getMainExecutor(app), () -> {
                        proxyActive = true;
                        ready.run();
                    });
            return true;
        } catch (Exception e) {
            if (proxy != null) proxy.stop();
            proxy = null;
            return false;
        }
    }

    private String readAsset(String name) {
        try (InputStream in = app.getAssets().open(name)) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }
}
