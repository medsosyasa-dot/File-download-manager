package app.filedownloadmanager;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.TreeSet;

/** Downloads public ad/tracker host lists and merges them into one file. */
final class BlocklistUpdater {

    interface Callback {
        void done(boolean ok, String message);
    }

    private static final String[] SOURCES = {
            "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&showintro=0&mimetype=plaintext",
            "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
    };

    private BlocklistUpdater() {
    }

    static void update(final Context context, final Callback callback) {
        final Context app = context.getApplicationContext();
        new Thread(() -> {
            Set<String> all = new TreeSet<>();
            int okSources = 0;
            for (String src : SOURCES) {
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(src).openConnection();
                    c.setConnectTimeout(20_000);
                    c.setReadTimeout(30_000);
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android)");
                    if (c.getResponseCode() != 200) continue;
                    try (BufferedReader r = new BufferedReader(new InputStreamReader(
                            c.getInputStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = r.readLine()) != null) {
                            String host = parse(line);
                            if (host != null) all.add(host);
                        }
                    }
                    okSources++;
                } catch (Exception ignored) {
                    // try the next source
                }
            }

            boolean ok = okSources > 0 && all.size() > 100;
            String message;
            if (ok) {
                try {
                    File tmp = new File(app.getFilesDir(), "blocklist.tmp");
                    try (BufferedWriter w = new BufferedWriter(new OutputStreamWriter(
                            new FileOutputStream(tmp), StandardCharsets.UTF_8))) {
                        for (String h : all) {
                            w.write(h);
                            w.newLine();
                        }
                    }
                    File dest = AdBlocker.listFile(app);
                    //noinspection ResultOfMethodCallIgnored
                    dest.delete();
                    ok = tmp.renameTo(dest);
                    if (ok) AdBlocker.reload(app);
                } catch (Exception e) {
                    ok = false;
                }
                message = ok ? "Daftar diperbarui: " + AdBlocker.count() + " alamat diblokir"
                        : "Gagal menyimpan daftar";
            } else {
                message = "Gagal mengunduh daftar. Periksa koneksi internet lalu coba lagi.";
            }
            final boolean fOk = ok;
            final String fMsg = message;
            new Handler(Looper.getMainLooper()).post(() -> callback.done(fOk, fMsg));
        }).start();
    }

    /** Reads one line of a hosts file ("0.0.0.0 example.com") and returns the host, or null. */
    private static String parse(String line) {
        int hash = line.indexOf('#');
        if (hash >= 0) line = line.substring(0, hash);
        line = line.trim();
        if (line.isEmpty()) return null;
        String[] parts = line.split("\\s+");
        if (parts.length < 2) return null;
        if (!(parts[0].equals("0.0.0.0") || parts[0].equals("127.0.0.1"))) return null;
        String host = parts[1].toLowerCase();
        if (host.equals("localhost") || host.equals("localhost.localdomain")
                || host.equals("local") || host.equals("broadcasthost")
                || host.equals("0.0.0.0") || host.indexOf('.') < 0 || host.contains("/")
                || host.contains(":") || AdBlocker.isAllowed(host)) {
            return null;
        }
        return host;
    }
}
