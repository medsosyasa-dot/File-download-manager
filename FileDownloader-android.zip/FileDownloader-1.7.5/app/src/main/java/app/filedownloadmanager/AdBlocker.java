package app.filedownloadmanager;

import android.content.Context;
import android.net.Uri;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.Set;

/** Decides which hosts and URLs are ads or trackers. */
final class AdBlocker {

    private static final Set<String> BUILTIN = new HashSet<>(Arrays.asList(
            // Google
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "2mdn.net", "googletagservices.com", "google-analytics.com",
            "googleanalytics.com", "analytics.google.com", "pagead2.googleadservices.com",
            // Ad networks
            "adnxs.com", "adsrvr.org", "amazon-adsystem.com", "taboola.com", "outbrain.com",
            "criteo.com", "criteo.net", "pubmatic.com", "rubiconproject.com", "openx.net",
            "smartadserver.com", "casalemedia.com", "moatads.com", "scorecardresearch.com",
            "quantserve.com", "mgid.com", "revcontent.com", "zedo.com", "adform.net",
            "advertising.com", "yieldmo.com", "media.net", "adcolony.com", "applovin.com",
            "unityads.unity3d.com", "popads.net", "popcash.net", "propellerads.com",
            "onclickads.net", "adsterra.com", "exoclick.com", "exosrv.com", "juicyads.com",
            "trafficjunky.net", "trafficfactory.biz", "hilltopads.net", "clickadu.com",
            "adcash.com", "richpush.co", "pushame.com", "adskeeper.com", "bidvertiser.com",
            // Analytics and session recording
            "hotjar.com", "hotjar.io", "mouseflow.com", "luckyorange.com", "luckyorange.net",
            "freshmarketer.com", "stats.wp.com", "mc.yandex.ru", "appmetrica.yandex.ru",
            "metrika.yandex.ru", "adfstat.yandex.ru", "adfox.yandex.ru", "an.yandex.ru",
            "offerwall.yandex.net", "extmaps-api.yandex.net", "bat.bing.com",
            // Error reporting used for tracking
            "bugsnag.com", "sentry-cdn.com", "getsentry.com", "sentry.io",
            // Social trackers
            "ads-api.tiktok.com", "ads-sg.tiktok.com", "ads.tiktok.com", "analytics.tiktok.com",
            "analytics-sg.tiktok.com", "business-api.tiktok.com", "byteoversea.com",
            "ads.pinterest.com", "log.pinterest.com", "trk.pinterest.com", "ct.pinterest.com",
            "ads.linkedin.com", "analytics.pointdrive.linkedin.com", "events.reddit.com",
            "events.redditmedia.com", "pixel.facebook.com", "an.facebook.com",
            "ads-twitter.com", "ads-api.twitter.com", "ads.twitter.com", "analytics.twitter.com",
            // Yahoo
            "ads.yahoo.com", "analytics.yahoo.com", "geo.yahoo.com", "udcm.yahoo.com",
            "analytics.query.yahoo.com", "partnerads.ysm.yahoo.com", "log.fc.yahoo.com",
            "gemini.yahoo.com", "adtech.yahooinc.com"
    ));

    /** Never blocked, even if a downloaded list contains them. */
    private static final Set<String> ALLOW = new HashSet<>(Arrays.asList(
            "youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "ytimg.com",
            "i.ytimg.com", "googlevideo.com", "google.com", "www.google.com", "gstatic.com",
            "www.gstatic.com", "googleapis.com", "fonts.googleapis.com", "accounts.google.com",
            "github.com", "githubusercontent.com", "raw.githubusercontent.com", "apkpure.com"
    ));

    /** Script file names that only exist to show or detect ads. */
    private static final Set<String> AD_SCRIPTS = new HashSet<>(Arrays.asList(
            "ads.js", "pagead.js", "adsbygoogle.js", "show_ads.js", "adframe.js", "adsense.js",
            "advertisement.js", "adserver.js", "ad.js", "adsbox.js", "ads-beacon.js"
    ));

    // YouTube serves ads from its own host, so those are matched by path.
    private static final String[] YOUTUBE_AD_PATHS = {
            "/pagead/", "/api/stats/ads", "/ptracking", "/get_midroll_info", "/api/stats/qoe?adformat"
    };

    private static volatile Set<String> hosts = BUILTIN;
    private static final Set<String> USER_ALLOW = Collections.synchronizedSet(new HashSet<String>());
    private static volatile long pausedUntil;
    private static final LinkedHashMap<String, Long> RECENT = new LinkedHashMap<String, Long>() {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Long> eldest) {
            return size() > 80;
        }
    };
    private static boolean loaded;

    private AdBlocker() {
    }

    static File listFile(Context c) {
        return new File(c.getFilesDir(), "blocklist.txt");
    }

    static synchronized void ensureLoaded(Context c) {
        if (!loaded) reload(c);
    }

    /** Built-in hosts plus the list downloaded in Settings (one host per line). */
    static synchronized void reload(Context c) {
        Set<String> all = new HashSet<>(BUILTIN);
        File f = listFile(c);
        if (f.exists()) {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(
                    new FileInputStream(f), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    line = line.trim();
                    if (!line.isEmpty() && !ALLOW.contains(line)) all.add(line);
                }
            } catch (IOException ignored) {
                // keep what we have
            }
        }
        hosts = all;
        synchronized (USER_ALLOW) {
            USER_ALLOW.clear();
            USER_ALLOW.addAll(Settings.allowSet(c));
        }
        loaded = true;
    }

    static int count() {
        return hosts.size();
    }

    static boolean isAllowed(String host) {
        return ALLOW.contains(host);
    }

    /** Switches all blocking off for a while (to find out what breaks a page). */
    static void pauseFor(long millis) {
        pausedUntil = System.currentTimeMillis() + millis;
    }

    static void resume() {
        pausedUntil = 0;
    }

    static boolean isPaused() {
        return System.currentTimeMillis() < pausedUntil;
    }

    static void allow(Context c, String host) {
        USER_ALLOW.add(host.toLowerCase(Locale.ROOT));
        synchronized (USER_ALLOW) {
            Settings.saveAllow(c, USER_ALLOW);
        }
    }

    static void recordBlocked(String what) {
        if (what == null) return;
        synchronized (RECENT) {
            RECENT.remove(what);
            RECENT.put(what, System.currentTimeMillis());
        }
    }

    /** Things blocked since the given time, newest first. */
    static List<String> blockedSince(long since) {
        List<String> out = new ArrayList<>();
        synchronized (RECENT) {
            for (Map.Entry<String, Long> e : RECENT.entrySet()) {
                if (e.getValue() >= since) out.add(0, e.getKey());
            }
        }
        return out;
    }

    private static boolean userAllowed(String host) {
        String h = host;
        while (true) {
            if (USER_ALLOW.contains(h)) return true;
            int dot = h.indexOf('.');
            if (dot < 0 || h.indexOf('.', dot + 1) < 0) return false;
            h = h.substring(dot + 1);
        }
    }

    static boolean isHostBlocked(String host) {
        if (host == null || isPaused()) return false;
        host = host.toLowerCase(Locale.ROOT);
        if (ALLOW.contains(host) || userAllowed(host)) return false;
        Set<String> set = hosts;
        String h = host;
        while (true) {
            if (set.contains(h)) return true;
            int dot = h.indexOf('.');
            if (dot < 0 || h.indexOf('.', dot + 1) < 0) return false;
            h = h.substring(dot + 1);
        }
    }

    static boolean isYoutubeAdPath(Uri uri) {
        if (isPaused()) return false;
        String host = uri.getHost();
        if (host == null) return false;
        host = host.toLowerCase(Locale.ROOT);
        if (!(host.equals("youtube.com") || host.endsWith(".youtube.com"))) return false;
        String path = uri.getPath();
        if (path == null) return false;
        for (String p : YOUTUBE_AD_PATHS) {
            if (path.contains(p)) return true;
        }
        return false;
    }

    static boolean isAdScript(Uri uri) {
        if (isPaused()) return false;
        String name = uri.getLastPathSegment();
        return name != null && AD_SCRIPTS.contains(name.toLowerCase(Locale.ROOT));
    }

    static boolean shouldBlock(Uri uri) {
        return isHostBlocked(uri.getHost()) || isYoutubeAdPath(uri);
    }
}
