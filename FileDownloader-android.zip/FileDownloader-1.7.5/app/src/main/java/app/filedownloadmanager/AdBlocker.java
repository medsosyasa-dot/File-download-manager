package app.filedownloadmanager;

import android.net.Uri;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Blocks requests to well-known ad and tracking hosts (and YouTube's ad endpoints). */
final class AdBlocker {

    private static final Set<String> HOSTS = new HashSet<>(Arrays.asList(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "pagead2.googlesyndication.com", "2mdn.net",
            "googletagservices.com", "google-analytics.com", "adnxs.com", "adsrvr.org",
            "amazon-adsystem.com", "taboola.com", "outbrain.com", "criteo.com", "criteo.net",
            "pubmatic.com", "rubiconproject.com", "openx.net", "smartadserver.com",
            "casalemedia.com", "moatads.com", "scorecardresearch.com", "quantserve.com",
            "mgid.com", "revcontent.com", "zedo.com", "adform.net", "advertising.com",
            "yieldmo.com", "media.net", "adcolony.com", "applovin.com", "unityads.unity3d.com",
            "popads.net", "popcash.net", "propellerads.com", "onclickads.net", "adsterra.com",
            "exoclick.com", "exosrv.com", "juicyads.com", "trafficjunky.net", "trafficfactory.biz",
            "hilltopads.net", "clickadu.com", "adcash.com", "richpush.co", "pushame.com",
            "an.yandex.ru", "mc.yandex.ru", "ads.yahoo.com", "ads.twitter.com",
            "analytics.twitter.com", "ads.linkedin.com", "facebook.net", "connect.facebook.net",
            "bat.bing.com", "hotjar.com", "mouseflow.com", "adskeeper.com", "bidvertiser.com"
    ));

    // YouTube serves ads from its own host, so those are matched by path.
    private static final String[] YOUTUBE_AD_PATHS = {
            "/pagead/", "/api/stats/ads", "/ptracking", "/get_midroll_info", "/api/stats/qoe?adformat"
    };

    private AdBlocker() {
    }

    static boolean shouldBlock(Uri uri) {
        String host = uri.getHost();
        if (host == null) return false;
        host = host.toLowerCase(Locale.ROOT);

        // Walk up the domain: a.b.example.com -> b.example.com -> example.com
        String h = host;
        while (true) {
            if (HOSTS.contains(h)) return true;
            int dot = h.indexOf('.');
            if (dot < 0 || h.indexOf('.', dot + 1) < 0) break;
            h = h.substring(dot + 1);
        }

        if (host.equals("youtube.com") || host.endsWith(".youtube.com")) {
            String path = uri.getPath();
            if (path != null) {
                for (String p : YOUTUBE_AD_PATHS) {
                    if (path.contains(p)) return true;
                }
            }
        }
        return false;
    }
}
