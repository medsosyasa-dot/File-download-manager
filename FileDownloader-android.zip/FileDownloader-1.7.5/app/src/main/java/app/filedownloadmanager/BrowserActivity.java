package app.filedownloadmanager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import java.net.URLEncoder;

/**
 * Small built-in browser. When a page starts a file download, the link is captured together
 * with the browser's cookies, user agent and referer, and handed to the download manager.
 */
public class BrowserActivity extends AppCompatActivity {

    private static final String HOME = "https://www.google.com";

    private WebView web;
    private EditText address;
    private ProgressBar progress;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);
        setTitle("Browser");
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        web = findViewById(R.id.web);
        address = findViewById(R.id.address);
        progress = findViewById(R.id.page_progress);

        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        // Look like a normal mobile browser rather than an embedded WebView.
        ws.setUserAgentString(ws.getUserAgentString().replace("; wv", ""));

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                // Stay inside the browser; ignore intent:, market: and similar links.
                return !("http".equals(scheme) || "https".equals(scheme));
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                address.setText(url);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? android.view.View.INVISIBLE
                        : android.view.View.VISIBLE);
            }
        });
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
                Toast.makeText(this, "Link download ini tidak didukung", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent result = new Intent();
            if (getIntent().hasExtra("refresh_id")) {
                result.putExtra("refresh_id", getIntent().getIntExtra("refresh_id", 0));
            }
            result.putExtra("url", url);
            result.putExtra("ua", userAgent);
            result.putExtra("cookie", CookieManager.getInstance().getCookie(url));
            result.putExtra("referer", web.getUrl());
            result.putExtra("mime", mimeType);
            result.putExtra("name", URLUtil.guessFileName(url, contentDisposition, mimeType));
            setResult(RESULT_OK, result);
            finish();
        });

        findViewById(R.id.go).setOnClickListener(v -> load());
        address.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                load();
                return true;
            }
            return false;
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (web.canGoBack()) {
                    web.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        String start = getIntent().getStringExtra("start");
        web.loadUrl(start != null ? start : HOME);
        if (getIntent().hasExtra("refresh_id")) {
            Toast.makeText(this, "Buka halaman download lagi lalu tekan Download "
                    + "untuk memperbarui link", Toast.LENGTH_LONG).show();
        }
    }

    private void load() {
        String text = address.getText().toString().trim();
        if (text.isEmpty()) return;
        String url;
        if (text.startsWith("http://") || text.startsWith("https://")) {
            url = text;
        } else if (!text.contains(" ") && text.contains(".")) {
            url = "https://" + text;
        } else {
            try {
                url = "https://www.google.com/search?q=" + URLEncoder.encode(text, "UTF-8");
            } catch (Exception e) {
                url = HOME;
            }
        }
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(address.getWindowToken(), 0);
        web.loadUrl(url);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.stopLoading();
            web.destroy();
        }
        super.onDestroy();
    }
}
