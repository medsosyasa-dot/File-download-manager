package app.filedownloadmanager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import androidx.core.content.ContextCompat;
import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

/**
 * Small built-in browser. When a page starts a file download, the link is captured together
 * with the browser's cookies, user agent and referer, and handed to the download manager.
 */
public class BrowserActivity extends AppCompatActivity {

    private static final String HOME = "https://www.google.com";

    private WebView web;
    private EditText address;
    private ProgressBar progress;
    private boolean adBlock;
    private String adScript;
    private boolean documentStartScript;
    private LocalProxy proxy;
    private volatile boolean proxyActive;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);
        setTitle("Browser");
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        web = findViewById(R.id.web);
        address = findViewById(R.id.address);
        progress = findViewById(R.id.page_progress);

        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        // Look like a normal mobile browser rather than an embedded WebView.
        ws.setUserAgentString(ws.getUserAgentString().replace("; wv", ""));

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(web, true);

        adBlock = Settings.adBlock(this);
        if (adBlock) {
            AdBlocker.ensureLoaded(this);
            adScript = readAsset("adblock.js");
            if (adScript != null && WebViewFeature.isFeatureSupported(
                    WebViewFeature.DOCUMENT_START_SCRIPT)) {
                // Runs before the page's own scripts, which YouTube blocking needs.
                WebViewCompat.addDocumentStartJavaScript(web, adScript,
                        Collections.singleton("*"));
                documentStartScript = true;
            }
        }

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view,
                                                              WebResourceRequest request) {
                if (adBlock) {
                    android.net.Uri u = request.getUrl();
                    // With the local proxy active, blocked hosts are refused by the proxy so the
                    // page sees a real network error; otherwise answer them here.
                    boolean block = AdBlocker.isAdScript(u) || AdBlocker.isYoutubeAdPath(u)
                            || (!proxyActive && AdBlocker.isHostBlocked(u.getHost()));
                    if (block) {
                        return new WebResourceResponse("text/plain", "utf-8", 404, "Blocked",
                                new java.util.HashMap<String, String>(),
                                new ByteArrayInputStream(new byte[0]));
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                // Stay inside the browser; ignore intent:, market: and similar links.
                if (!("http".equals(scheme) || "https".equals(scheme))) return true;
                // Also stop pop-up / redirect pages that belong to ad networks.
                return adBlock && AdBlocker.shouldBlock(request.getUrl());
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                address.setText(url);
                // Older WebView versions: inject late instead.
                if (adBlock && !documentStartScript && adScript != null) {
                    view.evaluateJavascript(adScript, null);
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? android.view.View.INVISIBLE
                        : android.view.View.VISIBLE);
            }
        });
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
                Toast.makeText(this, "Link download ini tidak didukung", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent result = new Intent();
            if (getIntent().hasExtra("refresh_id")) {
                result.putExtra("refresh_id", getIntent().getIntExtra("refresh_id", 0));
            }
            result.putExtra("url", url);
            result.putExtra("ua", userAgent);
            result.putExtra("cookie", CookieManager.getInstance().getCookie(url));
            result.putExtra("referer", web.getUrl());
            result.putExtra("mime", mimeType);
            result.putExtra("name", URLUtil.guessFileName(url, contentDisposition, mimeType));
            setResult(RESULT_OK, result);
            finish();
        });

        findViewById(R.id.go).setOnClickListener(v -> load());
        address.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                load();
                return true;
            }
            return false;
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (web.canGoBack()) {
                    web.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        final String start = getIntent().getStringExtra("start");
        final Runnable begin = () -> web.loadUrl(start != null ? start : HOME);
        if (!(adBlock && startProxy(begin))) begin.run();
        if (getIntent().hasExtra("refresh_id")) {
            Toast.makeText(this, "Buka halaman download lagi lalu tekan Download "
                    + "untuk memperbarui link", Toast.LENGTH_LONG).show();
        }
    }

    /** Routes the browser through the local blocking proxy; returns false if not possible. */
    private boolean startProxy(final Runnable ready) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return false;
        try {
            proxy = new LocalProxy();
            int port = proxy.start();
            ProxyConfig config = new ProxyConfig.Builder()
                    .addProxyRule("127.0.0.1:" + port)
                    .build();
            ProxyController.getInstance().setProxyOverride(config,
                    ContextCompat.getMainExecutor(this), () -> {
                        proxyActive = true;
                        ready.run();
                    });
            return true;
        } catch (Exception e) {
            if (proxy != null) proxy.stop();
            proxy = null;
            return false;
        }
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    private void load() {
        String text = address.getText().toString().trim();
        if (text.isEmpty()) return;
        String url;
        if (text.startsWith("http://") || text.startsWith("https://")) {
            url = text;
        } else if (!text.contains(" ") && text.contains(".")) {
            url = "https://" + text;
        } else {
            try {
                url = "https://www.google.com/search?q=" + URLEncoder.encode(text, "UTF-8");
            } catch (Exception e) {
                url = HOME;
            }
        }
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(address.getWindowToken(), 0);
        web.loadUrl(url);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @Override
    protected void onDestroy() {
        if (proxy != null) {
            proxyActive = false;
            try {
                ProxyController.getInstance().clearProxyOverride(
                        ContextCompat.getMainExecutor(this), () -> { });
            } catch (Exception ignored) {
                // not supported / already cleared
            }
            proxy.stop();
            proxy = null;
        }
        if (web != null) {
            web.stopLoading();
            web.destroy();
        }
        super.onDestroy();
    }
}
