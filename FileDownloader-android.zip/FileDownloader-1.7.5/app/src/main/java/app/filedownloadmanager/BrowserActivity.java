package app.filedownloadmanager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import com.google.android.material.button.MaterialButton;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Built-in browser with tabs. It captures file downloads and detects video/audio files that a
 * page plays, using the page's own cookies, user agent and referer.
 */
public class BrowserActivity extends AppCompatActivity {

    private static final String HOME = "https://www.google.com";
    private static final Pattern MEDIA_PATH = Pattern.compile(
            "\\.(mp4|webm|mkv|m4v|mov|flv|3gp|mp3|m4a|aac|ogg|wav)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern STREAM_PATH = Pattern.compile(
            "\\.(m3u8|mpd)$", Pattern.CASE_INSENSITIVE);

    static class Tab {
        WebView web;
        String url = "";
        String title = "";
        boolean pendingNewWindow;
        boolean asked;
        boolean userGesture;
        String parentUrl = "";
        final List<String> media = new ArrayList<>();
        final Set<String> mediaSet = new HashSet<>();

        String label() {
            if (!title.isEmpty()) return title;
            return url.isEmpty() ? "Tab baru" : url;
        }
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<Tab> tabs = new ArrayList<>();
    private Tab current;

    private FrameLayout container;
    private EditText address;
    private ProgressBar progress;
    private MaterialButton tabsBtn;
    private MaterialButton mediaBtn;

    private boolean adBlock;
    private String adScript;
    private String mediaScript;
    private boolean documentStartScript;
    private LocalProxy proxy;
    private volatile boolean proxyActive;
    private boolean dialogShowing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);
        setTitle("Browser");
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        container = findViewById(R.id.web_container);
        address = findViewById(R.id.address);
        progress = findViewById(R.id.page_progress);
        tabsBtn = findViewById(R.id.tabs_btn);
        mediaBtn = findViewById(R.id.media_btn);
        MaterialButton newTabBtn = findViewById(R.id.new_tab_btn);

        mediaScript = readAsset("media.js");
        adBlock = Settings.adBlock(this);
        if (adBlock) {
            AdBlocker.ensureLoaded(this);
            adScript = readAsset("adblock.js");
            documentStartScript = adScript != null
                    && WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        }

        findViewById(R.id.go).setOnClickListener(v -> load());
        address.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                load();
                return true;
            }
            return false;
        });
        tabsBtn.setOnClickListener(v -> showTabs());
        newTabBtn.setOnClickListener(v -> openBlankTab());
        mediaBtn.setOnClickListener(v -> showMedia());

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (current != null && current.web.canGoBack()) {
                    current.web.goBack();
                } else if (tabs.size() > 1) {
                    closeTab(current);
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        final String start = getIntent().getStringExtra("start");
        final Runnable begin = () -> {
            Tab t = createTab();
            tabs.add(t);
            switchTo(t);
            t.web.loadUrl(start != null ? start : HOME);
        };
        if (!(adBlock && startProxy(begin))) begin.run();
        if (getIntent().hasExtra("refresh_id")) {
            Toast.makeText(this, "Buka halaman download lagi lalu tekan Download "
                    + "untuk memperbarui link", Toast.LENGTH_LONG).show();
        }
    }

    // ---------------------------------------------------------------- tabs

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private Tab createTab() {
        final Tab tab = new Tab();
        WebView web = new WebView(this);
        tab.web = web;

        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        ws.setSupportMultipleWindows(true);
        ws.setJavaScriptCanOpenWindowsAutomatically(true);
        // Look like a normal mobile browser rather than an embedded WebView.
        ws.setUserAgentString(ws.getUserAgentString().replace("; wv", ""));

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new MediaBridge(tab), "FdmMedia");
        if (documentStartScript) {
            // Runs before the page's own scripts, which YouTube blocking needs.
            WebViewCompat.addDocumentStartJavaScript(web, adScript, Collections.singleton("*"));
        }

        web.setWebViewClient(new TabClient(tab));
        web.setWebChromeClient(new TabChrome(tab));
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, length) -> {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
                Toast.makeText(this, "Link download ini tidak didukung", Toast.LENGTH_SHORT).show();
                return;
            }
            Handoff.Request r = new Handoff.Request();
            r.url = url;
            r.ua = userAgent;
            r.cookie = CookieManager.getInstance().getCookie(url);
            r.referer = tab.url;
            r.mime = mimeType;
            r.name = URLUtil.guessFileName(url, contentDisposition, mimeType);
            deliver(r);
        });
        return tab;
    }

    private void switchTo(Tab tab) {
        current = tab;
        container.removeAllViews();
        if (tab.web.getParent() instanceof ViewGroup) {
            ((ViewGroup) tab.web.getParent()).removeView(tab.web);
        }
        container.addView(tab.web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        address.setText(tab.url);
        progress.setVisibility(View.INVISIBLE);
        updateButtons();
    }

    private void openBlankTab() {
        Tab t = createTab();
        tabs.add(t);
        switchTo(t);
        t.web.loadUrl(HOME);
    }

    private void closeTab(Tab tab) {
        if (tab == null) return;
        int index = tabs.indexOf(tab);
        tabs.remove(tab);
        destroyTab(tab);
        if (tabs.isEmpty()) {
            finish();
            return;
        }
        if (tab == current) {
            switchTo(tabs.get(Math.max(0, Math.min(index, tabs.size()) - 1)));
        } else {
            updateButtons();
        }
    }

    private void destroyTab(Tab tab) {
        try {
            tab.web.stopLoading();
            if (tab.web.getParent() instanceof ViewGroup) {
                ((ViewGroup) tab.web.getParent()).removeView(tab.web);
            }
            tab.web.destroy();
        } catch (Exception ignored) {
            // already destroyed
        }
    }

    private void showTabs() {
        String[] labels = new String[tabs.size()];
        for (int i = 0; i < labels.length; i++) {
            Tab t = tabs.get(i);
            labels[i] = (t == current ? "• " : "") + shorten(t.label(), 60);
        }
        new AlertDialog.Builder(this)
                .setTitle("Tab (" + tabs.size() + ")")
                .setItems(labels, (d, which) -> switchTo(tabs.get(which)))
                .setNeutralButton("Tab baru", (d, w) -> openBlankTab())
                .setNegativeButton("Tutup tab ini", (d, w) -> closeTab(current))
                .show();
    }

    private void updateButtons() {
        tabsBtn.setText("Tab " + tabs.size());
        boolean hasMedia = current != null && !current.media.isEmpty();
        mediaBtn.setVisibility(hasMedia ? View.VISIBLE : View.GONE);
        if (hasMedia) mediaBtn.setText("Media " + current.media.size());
    }

    // ------------------------------------------------- popups and redirects

    /** A page asked for a new window: ask before opening, unless it is a plain same-site link. */
    private void confirmNewWindow(final Tab tab, final String url) {
        if (tab.asked) return;
        tab.asked = true;
        Uri u = Uri.parse(url);
        if (adBlock && AdBlocker.shouldBlock(u)) {
            destroyTab(tab);
            return;
        }
        if (tab.userGesture && siteOf(tab.parentUrl).equals(siteOf(url))) {
            openPendingTab(tab, url);
            return;
        }
        if (dialogShowing) {
            destroyTab(tab);
            return;
        }
        dialogShowing = true;
        new AlertDialog.Builder(this)
                .setTitle("Halaman ingin membuka tab baru")
                .setMessage(shorten(url, 160))
                .setCancelable(false)
                .setPositiveButton("Lanjut", (d, w) -> openPendingTab(tab, url))
                .setNegativeButton("Tetap di sini", (d, w) -> destroyTab(tab))
                .setOnDismissListener(d -> dialogShowing = false)
                .show();
    }

    private void openPendingTab(Tab tab, String url) {
        tab.pendingNewWindow = false;
        tabs.add(tab);
        switchTo(tab);
        tab.web.loadUrl(url);
    }

    /** A page tried to move itself to another site without any tap: ask first. */
    private void confirmRedirect(final Tab tab, final String url) {
        if (dialogShowing) return;
        dialogShowing = true;
        new AlertDialog.Builder(this)
                .setTitle("Situs mencoba pindah halaman")
                .setMessage(shorten(url, 160))
                .setCancelable(false)
                .setPositiveButton("Lanjut", (d, w) -> tab.web.loadUrl(url))
                .setNegativeButton("Tetap di sini", null)
                .setOnDismissListener(d -> dialogShowing = false)
                .show();
    }

    /** Rough "same website" key: the last two host labels (three for names like example.co.id). */
    private static String siteOf(String url) {
        String host = Uri.parse(url == null ? "" : url).getHost();
        if (host == null) return "";
        String[] p = host.toLowerCase(Locale.ROOT).split("\\.");
        int n = p.length;
        if (n >= 3 && p[n - 1].length() == 2 && p[n - 2].length() <= 3) {
            return p[n - 3] + "." + p[n - 2] + "." + p[n - 1];
        }
        return n >= 2 ? p[n - 2] + "." + p[n - 1] : host;
    }

    private static String shorten(String s, int max) {
        return s.length() > max ? s.substring(0, max) + "…" : s;
    }

    // ---------------------------------------------------------- media

    private void addMedia(Tab tab, String url) {
        if (tab.mediaSet.size() >= 100 || !tab.mediaSet.add(url)) return;
        tab.media.add(url);
        if (tab == current) updateButtons();
    }

    private static boolean isStream(String url) {
        String path = Uri.parse(url).getPath();
        return path != null && STREAM_PATH.matcher(path).find();
    }

    private void showMedia() {
        if (current == null || current.media.isEmpty()) return;
        final Tab tab = current;
        final List<String> list = new ArrayList<>(tab.media);
        String[] labels = new String[list.size()];
        for (int i = 0; i < labels.length; i++) {
            String url = list.get(i);
            Uri u = Uri.parse(url);
            String file = u.getLastPathSegment() == null ? "media" : u.getLastPathSegment();
            labels[i] = (isStream(url) ? "[Stream, belum didukung] " : "")
                    + shorten(file, 50) + "\n" + u.getHost();
        }
        new AlertDialog.Builder(this)
                .setTitle("Media terdeteksi (" + list.size() + ")")
                .setItems(labels, (d, which) -> {
                    String url = list.get(which);
                    if (isStream(url)) {
                        Toast.makeText(this, "Stream HLS/DASH belum bisa diunduh",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                    Handoff.Request r = new Handoff.Request();
                    r.url = url;
                    r.ua = tab.web.getSettings().getUserAgentString();
                    r.cookie = CookieManager.getInstance().getCookie(url);
                    r.referer = tab.url;
                    r.name = mediaName(tab, url);
                    deliver(r);
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private static String mediaName(Tab tab, String url) {
        String ext = "mp4";
        String path = Uri.parse(url).getPath();
        if (path != null) {
            int dot = path.lastIndexOf('.');
            if (dot >= 0 && path.length() - dot <= 6) ext = path.substring(dot + 1).toLowerCase(Locale.ROOT);
        }
        String base = tab.title.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (base.isEmpty()) base = "video";
        if (base.length() > 80) base = base.substring(0, 80).trim();
        return base + "." + ext;
    }

    private void deliver(Handoff.Request r) {
        if (getIntent().hasExtra("refresh_id")) {
            // Replacing the link of an existing download: hand it back and close.
            Intent result = new Intent();
            result.putExtra("refresh_id", getIntent().getIntExtra("refresh_id", 0));
            result.putExtra("url", r.url);
            result.putExtra("ua", r.ua);
            result.putExtra("cookie", r.cookie);
            result.putExtra("referer", r.referer);
            result.putExtra("mime", r.mime);
            result.putExtra("name", r.name);
            setResult(RESULT_OK, result);
            finish();
            return;
        }
        Handoff.submit(r);
        Toast.makeText(this, "Download ditambahkan: " + r.name, Toast.LENGTH_SHORT).show();
    }

    /** Receives video/audio addresses found by the page scan (runs on a background thread). */
    private class MediaBridge {
        private final Tab tab;

        MediaBridge(Tab tab) {
            this.tab = tab;
        }

        @JavascriptInterface
        public void found(final String url) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
            runOnUiThread(() -> addMedia(tab, url));
        }
    }

    // ------------------------------------------------------ web clients

    private class TabClient extends WebViewClient {
        private final Tab tab;

        TabClient(Tab tab) {
            this.tab = tab;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            if (adBlock) {
                // With the local proxy active, blocked hosts are refused by the proxy so the
                // page sees a real network error; otherwise answer them here.
                boolean block = AdBlocker.isAdScript(u) || AdBlocker.isYoutubeAdPath(u)
                        || (!proxyActive && AdBlocker.isHostBlocked(u.getHost()));
                if (block) {
                    return new WebResourceResponse("text/plain", "utf-8", 404, "Blocked",
                            new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
                }
            }
            if ("GET".equalsIgnoreCase(request.getMethod())) {
                String path = u.getPath();
                if (path != null && (MEDIA_PATH.matcher(path).find()
                        || STREAM_PATH.matcher(path).find())) {
                    final String s = u.toString();
                    runOnUiThread(() -> addMedia(tab, s));
                }
            }
            return super.shouldInterceptRequest(view, request);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            String scheme = u.getScheme();
            // Stay inside the browser; ignore intent:, market: and similar links.
            if (!("http".equals(scheme) || "https".equals(scheme))) return true;
            if (adBlock && AdBlocker.shouldBlock(u)) return true;
            if (tab.pendingNewWindow) {
                confirmNewWindow(tab, u.toString());
                return true;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N
                    && request.isForMainFrame() && !request.hasGesture() && !request.isRedirect()
                    && !tab.url.isEmpty()
                    && !siteOf(tab.url).equals(siteOf(u.toString()))) {
                confirmRedirect(tab, u.toString());
                return true;
            }
            return false;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            if (tab.pendingNewWindow) {
                if (url != null && url.startsWith("http")) {
                    view.stopLoading();
                    confirmNewWindow(tab, url);
                }
                return;
            }
            tab.url = url == null ? "" : url;
            tab.media.clear();
            tab.mediaSet.clear();
            if (tab == current) {
                address.setText(tab.url);
                updateButtons();
            }
            // Older WebView versions: inject the ad blocking script late instead.
            if (adBlock && !documentStartScript && adScript != null) {
                view.evaluateJavascript(adScript, null);
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (mediaScript != null && !tab.pendingNewWindow) {
                view.evaluateJavascript(mediaScript, null);
            }
        }
    }

    private class TabChrome extends WebChromeClient {
        private final Tab tab;

        TabChrome(Tab tab) {
            this.tab = tab;
        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            if (tab != current) return;
            progress.setProgress(newProgress);
            progress.setVisibility(newProgress >= 100 ? View.INVISIBLE : View.VISIBLE);
        }

        @Override
        public void onReceivedTitle(WebView view, String title) {
            tab.title = title == null ? "" : title;
        }

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                      Message resultMsg) {
            final Tab nt = createTab();
            nt.pendingNewWindow = true;
            nt.userGesture = isUserGesture;
            nt.parentUrl = tab.url;
            WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
            transport.setWebView(nt.web);
            resultMsg.sendToTarget();
            // If the new window never navigates anywhere, drop it.
            handler.postDelayed(() -> {
                if (nt.pendingNewWindow && !nt.asked) destroyTab(nt);
            }, 20_000);
            return true;
        }

        @Override
        public void onCloseWindow(WebView window) {
            if (tab.pendingNewWindow) return;
            closeTab(tab);
        }
    }

    // ------------------------------------------------ proxy and helpers

    /** Routes the browser through the local blocking proxy; returns false if not possible. */
    private boolean startProxy(final Runnable ready) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return false;
        try {
            proxy = new LocalProxy();
            int port = proxy.start();
            ProxyConfig config = new ProxyConfig.Builder()
                    .addProxyRule("127.0.0.1:" + port)
                    .build();
            ProxyController.getInstance().setProxyOverride(config,
                    ContextCompat.getMainExecutor(this), () -> {
                        proxyActive = true;
                        ready.run();
                    });
            return true;
        } catch (Exception e) {
            if (proxy != null) proxy.stop();
            proxy = null;
            return false;
        }
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    private void load() {
        if (current == null) return;
        String text = address.getText().toString().trim();
        if (text.isEmpty()) return;
        String url;
        if (text.startsWith("http://") || text.startsWith("https://")) {
            url = text;
        } else if (!text.contains(" ") && text.contains(".")) {
            url = "https://" + text;
        } else {
            try {
                url = "https://www.google.com/search?q=" + URLEncoder.encode(text, "UTF-8");
            } catch (Exception e) {
                url = HOME;
            }
        }
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(address.getWindowToken(), 0);
        current.web.loadUrl(url);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (proxy != null) {
            proxyActive = false;
            try {
                ProxyController.getInstance().clearProxyOverride(
                        ContextCompat.getMainExecutor(this), () -> { });
            } catch (Exception ignored) {
                // not supported / already cleared
            }
            proxy.stop();
            proxy = null;
        }
        for (Tab t : new ArrayList<>(tabs)) destroyTab(t);
        tabs.clear();
        super.onDestroy();
    }
}
