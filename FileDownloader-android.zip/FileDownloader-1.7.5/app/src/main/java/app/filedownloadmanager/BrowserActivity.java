package app.filedownloadmanager;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Browser screen. The tabs themselves live in {@link BrowserSession}, so leaving this screen and
 * coming back shows every page exactly as it was.
 */
public class BrowserActivity extends AppCompatActivity implements BrowserSession.Host {

    private BrowserSession session;
    private DrawerLayout drawer;
    private FrameLayout container;
    private EditText address;
    private ProgressBar progress;
    private MaterialButton tabsBtn;
    private MaterialButton mediaBtn;
    private MaterialButton drmBtn;
    private TextView panelTitle;
    private TabAdapter tabAdapter;
    private RecyclerView tabList;
    private boolean dialogShowing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);
        setTitle("Browser");
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        drawer = findViewById(R.id.drawer);
        container = findViewById(R.id.web_container);
        address = findViewById(R.id.address);
        progress = findViewById(R.id.page_progress);
        tabsBtn = findViewById(R.id.tabs_btn);
        mediaBtn = findViewById(R.id.media_btn);
        drmBtn = findViewById(R.id.drm_btn);
        panelTitle = findViewById(R.id.panel_title);
        tabList = findViewById(R.id.tab_list);

        session = BrowserSession.get(this);
        session.host = this;
        session.attach(this);

        tabAdapter = new TabAdapter();
        tabList.setLayoutManager(new LinearLayoutManager(this));
        tabList.setAdapter(tabAdapter);

        findViewById(R.id.go).setOnClickListener(v -> load());
        address.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                load();
                return true;
            }
            return false;
        });
        tabsBtn.setOnClickListener(v -> drawer.openDrawer(GravityCompat.START));
        mediaBtn.setOnClickListener(v -> showMedia());
        drmBtn.setOnClickListener(v -> showDrm());

        findViewById(R.id.btn_add).setOnClickListener(v -> {
            drawer.closeDrawers();
            session.openTab(BrowserSession.HOME);
        });
        findViewById(R.id.btn_back).setOnClickListener(v -> {
            BrowserTab t = session.current;
            if (t != null && t.web != null && t.web.canGoBack()) t.web.goBack();
        });
        findViewById(R.id.btn_forward).setOnClickListener(v -> {
            BrowserTab t = session.current;
            if (t != null && t.web != null && t.web.canGoForward()) t.web.goForward();
        });
        findViewById(R.id.btn_home).setOnClickListener(v -> {
            BrowserTab t = session.current;
            if (t != null && t.web != null) {
                drawer.closeDrawers();
                t.web.loadUrl(BrowserSession.HOME);
            }
        });
        findViewById(R.id.btn_exit).setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Keluar dari browser?")
                .setMessage("Semua tab akan ditutup.")
                .setPositiveButton("Keluar", (d, w) -> {
                    session.closeAll();
                    finish();
                })
                .setNegativeButton(R.string.cancel, null)
                .show());

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                BrowserTab t = session.current;
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawers();
                } else if (t != null && t.web != null && t.web.canGoBack()) {
                    t.web.goBack();
                } else if (t != null && t.fromPopup && session.tabs.size() > 1) {
                    session.close(t);
                } else {
                    // Leave the screen; the tabs stay alive for next time.
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        final String start = getIntent().getStringExtra("start");
        session.start(() -> {
            session.restoreIfNeeded();
            if (start != null) session.openTab(start);
            else if (session.tabs.isEmpty()) session.openTab(BrowserSession.HOME);
            else if (session.current != null) session.select(session.current);
            if (getIntent().hasExtra("refresh_id")) {
                Toast.makeText(this, "Buka halaman download lagi lalu tekan Download "
                        + "untuk memperbarui link", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        session.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        session.pause();
        session.save();
    }

    @Override
    protected void onDestroy() {
        container.removeAllViews();
        session.detach(this);
        super.onDestroy();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    // --------------------------------------------------------- host callbacks

    @Override
    public void onTabsChanged() {
        container.removeAllViews();
        BrowserTab t = session.current;
        if (t != null && t.web != null) {
            if (t.web.getParent() instanceof ViewGroup) {
                ((ViewGroup) t.web.getParent()).removeView(t.web);
            }
            container.addView(t.web, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            address.setText(t.url);
        } else {
            address.setText("");
        }
        progress.setVisibility(View.INVISIBLE);
        updateButtons();
        tabAdapter.notifyDataSetChanged();
        int pos = session.tabs.indexOf(session.current);
        if (pos >= 0) tabList.scrollToPosition(pos);
    }

    @Override
    public void onTabUpdated(BrowserTab tab) {
        int pos = session.tabs.indexOf(tab);
        if (pos >= 0) tabAdapter.notifyItemChanged(pos);
        if (tab == session.current && !address.hasFocus()) address.setText(tab.url);
    }

    @Override
    public void onProgress(BrowserTab tab, int percent) {
        if (tab != session.current) return;
        progress.setProgress(percent);
        progress.setVisibility(percent >= 100 ? View.INVISIBLE : View.VISIBLE);
    }

    @Override
    public void onMediaChanged(BrowserTab tab) {
        if (tab == session.current) updateButtons();
    }

    @Override
    public void confirmNewWindow(final BrowserTab tab, final String url) {
        if (dialogShowing) {
            session.destroyPending(tab);
            return;
        }
        dialogShowing = true;
        new AlertDialog.Builder(this)
                .setTitle("Halaman ingin membuka tab baru")
                .setMessage(shorten(url, 160))
                .setCancelable(false)
                .setPositiveButton("Lanjut", (d, w) -> session.openPending(tab, url))
                .setNegativeButton("Tetap di sini", (d, w) -> session.destroyPending(tab))
                .setOnDismissListener(d -> dialogShowing = false)
                .show();
    }

    @Override
    public void confirmRedirect(final BrowserTab tab, final String url) {
        if (dialogShowing) return;
        dialogShowing = true;
        new AlertDialog.Builder(this)
                .setTitle("Situs mencoba pindah halaman")
                .setMessage(shorten(url, 160))
                .setCancelable(false)
                .setPositiveButton("Lanjut", (d, w) -> {
                    if (tab.web != null) tab.web.loadUrl(url);
                })
                .setNegativeButton("Tetap di sini", null)
                .setOnDismissListener(d -> dialogShowing = false)
                .show();
    }

    @Override
    public void deliver(Handoff.Request r) {
        if (getIntent().hasExtra("refresh_id")) {
            // Replacing the link of an existing download: hand it back and close.
            Intent result = new Intent();
            result.putExtra("refresh_id", getIntent().getIntExtra("refresh_id", 0));
            result.putExtra("url", r.url);
            result.putExtra("ua", r.ua);
            result.putExtra("cookie", r.cookie);
            result.putExtra("referer", r.referer);
            result.putExtra("mime", r.mime);
            result.putExtra("name", r.name);
            setResult(RESULT_OK, result);
            finish();
            return;
        }
        Handoff.submit(r);
        Toast.makeText(this, "Download ditambahkan: " + r.name, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------- UI

    private void updateButtons() {
        BrowserTab t = session.current;
        int n = session.tabs.size();
        tabsBtn.setText("Tab " + n);
        panelTitle.setText("Tab (" + n + ")");
        boolean hasMedia = t != null && !t.media.isEmpty();
        mediaBtn.setVisibility(hasMedia ? View.VISIBLE : View.GONE);
        if (hasMedia) mediaBtn.setText("Media " + t.media.size());
        drmBtn.setVisibility(t != null && t.drm != null ? View.VISIBLE : View.GONE);
        if (t != null && t.drm != null) drmBtn.setText("DRM");
    }

    private void showMedia() {
        final BrowserTab tab = session.current;
        if (tab == null || tab.media.isEmpty()) return;
        final List<String> list = new ArrayList<>(tab.media);
        String[] labels = new String[list.size()];
        for (int i = 0; i < labels.length; i++) {
            String url = list.get(i);
            Uri u = Uri.parse(url);
            String file = u.getLastPathSegment() == null ? "media" : u.getLastPathSegment();
            String info = tab.mediaInfo.get(url);
            String badge = "";
            if (BrowserSession.isDrmLabel(info)) badge = "[DRM " + info + "] ";
            else if (BrowserSession.isStream(url)) badge = "[Stream] ";
            labels[i] = badge + shorten(file, 50) + "\n" + u.getHost();
        }
        new AlertDialog.Builder(this)
                .setTitle("Media terdeteksi (" + list.size() + ")")
                .setItems(labels, (d, which) -> {
                    String url = list.get(which);
                    String info = tab.mediaInfo.get(url);
                    if (BrowserSession.isDrmLabel(info)) {
                        showDrmInfo(info);
                    } else if (BrowserSession.isStream(url)) {
                        Toast.makeText(this, "Stream HLS/DASH belum bisa diunduh",
                                Toast.LENGTH_LONG).show();
                    } else {
                        Handoff.Request r = new Handoff.Request();
                        r.url = url;
                        r.ua = session.userAgent();
                        r.cookie = CookieManager.getInstance().getCookie(url);
                        r.referer = tab.url;
                        r.name = mediaName(tab, url);
                        deliver(r);
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private void showDrm() {
        BrowserTab t = session.current;
        if (t != null && t.drm != null) showDrmInfo(t.drm);
    }

    private void showDrmInfo(String system) {
        new AlertDialog.Builder(this)
                .setTitle("Dilindungi DRM (" + system + ")")
                .setMessage("Video di halaman ini dienkripsi dengan DRM. Video seperti ini tidak "
                        + "bisa diunduh sebagai file biasa, dan aplikasi ini tidak mencoba "
                        + "membukanya. Kalau tersedia, gunakan fitur unduh resmi dari "
                        + "layanannya.")
                .setPositiveButton("Mengerti", null)
                .show();
    }

    private static String mediaName(BrowserTab tab, String url) {
        String ext = "mp4";
        String path = Uri.parse(url).getPath();
        if (path != null) {
            int dot = path.lastIndexOf('.');
            if (dot >= 0 && path.length() - dot <= 6) {
                ext = path.substring(dot + 1).toLowerCase(Locale.ROOT);
            }
        }
        String base = tab.title.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (base.isEmpty()) base = "video";
        if (base.length() > 80) base = base.substring(0, 80).trim();
        return base + "." + ext;
    }

    private static String shorten(String s, int max) {
        return s.length() > max ? s.substring(0, max) + "…" : s;
    }

    private void load() {
        BrowserTab t = session.current;
        if (t == null || t.web == null) return;
        String text = address.getText().toString().trim();
        if (text.isEmpty()) return;
        String url;
        if (text.startsWith("http://") || text.startsWith("https://")) {
            url = text;
        } else if (!text.contains(" ") && text.contains(".")) {
            url = "https://" + text;
        } else {
            try {
                url = "https://www.google.com/search?q=" + URLEncoder.encode(text, "UTF-8");
            } catch (Exception e) {
                url = BrowserSession.HOME;
            }
        }
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(address.getWindowToken(), 0);
        address.clearFocus();
        t.web.loadUrl(url);
    }

    // ------------------------------------------------------------ tab list

    private class TabAdapter extends RecyclerView.Adapter<TabAdapter.Holder> {

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_tab, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            final BrowserTab t = session.tabs.get(position);
            h.number.setText((position + 1) + ".");
            if (t.icon != null) h.icon.setImageBitmap(t.icon);
            else h.icon.setImageResource(R.drawable.ic_globe);
            h.title.setText(t.label());
            h.itemView.setBackgroundColor(t == session.current ? 0x3300D9C0 : 0);
            h.itemView.setOnClickListener(v -> {
                session.select(t);
                drawer.closeDrawers();
            });
            h.close.setOnClickListener(v -> {
                session.close(t);
                if (session.tabs.isEmpty()) finish();
            });
        }

        @Override
        public int getItemCount() {
            return session.tabs.size();
        }

        class Holder extends RecyclerView.ViewHolder {
            final TextView number;
            final ImageView icon;
            final TextView title;
            final ImageButton close;

            Holder(View v) {
                super(v);
                number = v.findViewById(R.id.tab_number);
                icon = v.findViewById(R.id.tab_icon);
                title = v.findViewById(R.id.tab_title);
                close = v.findViewById(R.id.tab_close);
            }
        }
    }
}
