package app.filedownloadmanager;

import android.app.Application;

import com.liulishuo.filedownloader.FileDownloader;
import com.liulishuo.filedownloader.connection.FileDownloadUrlConnection;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        FileDownloader.setupOnApplicationOnCreate(this)
                .connectionCreator(new FileDownloadUrlConnection.Creator(
                        new FileDownloadUrlConnection.Configuration()
                                .connectTimeout(15_000)
                                .readTimeout(30_000)))
                .connectionCountAdapter((downloadId, url, path, totalLength) -> {
                    int wanted = Settings.connectionsFromPath(path);
                    // Keep every part at least ~1 MB, otherwise many parts only add overhead.
                    long bySize = Math.max(1, totalLength / (1024 * 1024));
                    return (int) Math.max(1, Math.min(wanted, bySize));
                })
                .commit();
    }
}
