package app.filedownloadmanager;

import android.app.Application;

import com.liulishuo.filedownloader.FileDownloader;
import com.liulishuo.filedownloader.connection.FileDownloadUrlConnection;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        FileDownloader.setupOnApplicationOnCreate(this)
                .connectionCreator(new FileDownloadUrlConnection.Creator(
                        new FileDownloadUrlConnection.Configuration()
                                .connectTimeout(15_000)
                                .readTimeout(30_000)))
                .commit();
    }
}
