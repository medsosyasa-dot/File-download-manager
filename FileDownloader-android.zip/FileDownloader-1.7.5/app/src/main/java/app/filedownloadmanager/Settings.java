package app.filedownloadmanager;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class Settings {
    static final int DEFAULT_CONNECTIONS = 8;
    static final int MAX_CONNECTIONS = 100;

    private static final String PREFS = "settings";
    private static final String KEY_CONNECTIONS = "connections";
    private static final String KEY_TREE = "treeUri";
    // The per-download folder name carries the part count ("dl_<time>_c<count>"), because the
    // download engine may run in another process and cannot read our preferences reliably.
    private static final Pattern PATH_COUNT = Pattern.compile("dl_\\d+_c(\\d+)");

    private Settings() {
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static int connections(Context c) {
        return clamp(prefs(c).getInt(KEY_CONNECTIONS, DEFAULT_CONNECTIONS));
    }

    static void setConnections(Context c, int n) {
        prefs(c).edit().putInt(KEY_CONNECTIONS, clamp(n)).apply();
    }

    /** Tree URI of the folder chosen by the user, or null for the default Download folder. */
    static String treeUri(Context c) {
        return prefs(c).getString(KEY_TREE, null);
    }

    static void setTreeUri(Context c, String uri) {
        SharedPreferences.Editor e = prefs(c).edit();
        if (uri == null) e.remove(KEY_TREE);
        else e.putString(KEY_TREE, uri);
        e.apply();
    }

    static int connectionsFromPath(String path) {
        if (path != null) {
            Matcher m = PATH_COUNT.matcher(path);
            if (m.find()) {
                try {
                    return clamp(Integer.parseInt(m.group(1)));
                } catch (NumberFormatException ignored) {
                    // use default
                }
            }
        }
        return DEFAULT_CONNECTIONS;
    }

    private static int clamp(int n) {
        return Math.max(1, Math.min(MAX_CONNECTIONS, n));
    }
}
