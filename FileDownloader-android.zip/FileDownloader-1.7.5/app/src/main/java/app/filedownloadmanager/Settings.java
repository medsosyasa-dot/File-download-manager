package app.filedownloadmanager;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class Settings {
    static final int DEFAULT_CONNECTIONS = 8;
    static final int MAX_CONNECTIONS = 100;

    private static final String PREFS = "settings";
    private static final String KEY_CONNECTIONS = "connections";
    private static final String KEY_TREE = "treeUri";
    private static final String KEY_ADBLOCK = "adblock";
    // The per-download folder name carries the part count ("dl_<time>_c<count>"), because the
    // download engine may run in another process and cannot read our preferences reliably.
    private static final Pattern PATH_COUNT = Pattern.compile("dl_\\d+_c(\\d+)");

    private Settings() {
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static int connections(Context c) {
        return clamp(prefs(c).getInt(KEY_CONNECTIONS, DEFAULT_CONNECTIONS));
    }

    static void setConnections(Context c, int n) {
        prefs(c).edit().putInt(KEY_CONNECTIONS, clamp(n)).apply();
    }

    /** Tree URI of the folder chosen by the user, or null for the default Download folder. */
    static String treeUri(Context c) {
        return prefs(c).getString(KEY_TREE, null);
    }

    static void setTreeUri(Context c, String uri) {
        SharedPreferences.Editor e = prefs(c).edit();
        if (uri == null) e.remove(KEY_TREE);
        else e.putString(KEY_TREE, uri);
        e.apply();
    }

    /** Part limit learned for a host that refused many connections (0 = none). */
    static int hostCap(Context c, String host) {
        return prefs(c).getInt("cap_" + host.toLowerCase(java.util.Locale.ROOT), 0);
    }

    static void setHostCap(Context c, String host, int n) {
        prefs(c).edit().putInt("cap_" + host.toLowerCase(java.util.Locale.ROOT), n).apply();
    }

    static void clearHostCaps(Context c) {
        SharedPreferences.Editor e = prefs(c).edit();
        for (String k : prefs(c).getAll().keySet()) if (k.startsWith("cap_")) e.remove(k);
        e.remove("allow");
        e.apply();
    }

    static java.util.Set<String> allowSet(Context c) {
        java.util.Set<String> s = prefs(c).getStringSet("allow", null);
        return s == null ? new java.util.HashSet<String>() : new java.util.HashSet<>(s);
    }

    static void saveAllow(Context c, java.util.Set<String> s) {
        prefs(c).edit().putStringSet("allow", new java.util.HashSet<>(s)).apply();
    }

    static boolean wide(Context c) {
        return prefs(c).getBoolean("wide", false);
    }

    static void setWide(Context c, boolean on) {
        prefs(c).edit().putBoolean("wide", on).apply();
    }

    static boolean bgPlay(Context c) {
        return prefs(c).getBoolean("bgplay", true);
    }

    static void setBgPlay(Context c, boolean on) {
        prefs(c).edit().putBoolean("bgplay", on).apply();
    }

    static boolean adBlock(Context c) {
        return prefs(c).getBoolean(KEY_ADBLOCK, true);
    }

    static void setAdBlock(Context c, boolean on) {
        prefs(c).edit().putBoolean(KEY_ADBLOCK, on).apply();
    }

    static int connectionsFromPath(String path) {
        if (path != null) {
            Matcher m = PATH_COUNT.matcher(path);
            if (m.find()) {
                try {
                    return clamp(Integer.parseInt(m.group(1)));
                } catch (NumberFormatException ignored) {
                    // use default
                }
            }
        }
        return DEFAULT_CONNECTIONS;
    }

    private static int clamp(int n) {
        return Math.max(1, Math.min(MAX_CONNECTIONS, n));
    }
}
