package app.filedownloadmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/** Draws one block per download part, filled according to how much of that part is done. */
public class SegmentBar extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gap = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private float[] fractions;

    public SegmentBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        track.setColor(0x33888888);
        fill.setColor(0xFF00D9C0);
        gap.setColor(0xFF111111);
        gap.setStrokeWidth(2f);
    }

    void setSegments(float[] f) {
        this.fractions = f;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        rect.set(0, 0, w, h);
        canvas.drawRoundRect(rect, h / 3, h / 3, track);
        if (fractions == null || fractions.length == 0) return;
        int n = fractions.length;
        float segW = w / n;
        for (int i = 0; i < n; i++) {
            float left = i * segW;
            float f = Math.max(0f, Math.min(1f, fractions[i]));
            canvas.drawRect(left, 0, left + segW * f, h, fill);
        }
        if (n <= 40) {
            for (int i = 1; i < n; i++) {
                canvas.drawLine(i * segW, 0, i * segW, h, gap);
            }
        }
    }
}
