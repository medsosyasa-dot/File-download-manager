package app.filedownloadmanager;

import android.graphics.Bitmap;
import android.webkit.WebView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** One browser tab. {@link #web} is null for a restored tab that has not been opened yet. */
class BrowserTab {
    WebView web;
    String url = "";
    String title = "";
    Bitmap icon;
    boolean pendingNewWindow;
    boolean asked;
    boolean userGesture;
    boolean fromPopup;
    boolean playing;
    /** A locked tab is kept when the other tabs are closed. */
    boolean locked;
    String parentUrl = "";
    long lastUsed;
    long pageStartedAt;
    /** Name of the DRM system the page uses, or null. */
    String drm;
    final List<String> media = new ArrayList<>();
    final Set<String> mediaSet = new HashSet<>();
    /** Per stream address: what its manifest says ("" = checked, nothing special). */
    final Map<String, String> mediaInfo = new HashMap<>();

    String label() {
        if (!title.isEmpty()) return title;
        return url.isEmpty() ? "Tab baru" : url;
    }
}
