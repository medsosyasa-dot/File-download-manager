package app.filedownloadmanager;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.liulishuo.filedownloader.BaseDownloadTask;
import com.liulishuo.filedownloader.FileDownloadLargeFileListener;
import com.liulishuo.filedownloader.FileDownloader;
import com.liulishuo.filedownloader.model.FileDownloadStatus;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements DownloadAdapter.Callback {

    private static final Pattern URL_PATTERN = Pattern.compile("https?://\\S+");

    private List<DownloadItem> items;
    private DownloadAdapter adapter;
    private View root;
    private View emptyView;
    private String lastClipUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        root = findViewById(R.id.root);
        emptyView = findViewById(R.id.empty);
        RecyclerView list = findViewById(R.id.list);
        FloatingActionButton fab = findViewById(R.id.fab);

        items = DownloadStore.load(this);
        adapter = new DownloadAdapter(items, this);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
        fab.setOnClickListener(v -> showAddDialog(""));
        updateEmpty();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        // Retry saving files that finished but were not yet moved to the Download folder.
        for (DownloadItem item : items) {
            if (item.isCompleted() && item.savedUri == null && new File(item.path).exists()) {
                moveToDownloads(item);
            }
        }

        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent != null && Intent.ACTION_VIEW.equals(intent.getAction())
                && intent.getDataString() != null) {
            String url = extractUrl(intent.getDataString());
            if (url != null) showAddDialog(url);
            setIntent(new Intent());
            return;
        }
        if (intent != null && Intent.ACTION_SEND.equals(intent.getAction())) {
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            String url = extractUrl(text);
            if (url != null) {
                showAddDialog(url);
            } else {
                Toast.makeText(this, "Tidak ada link yang valid", Toast.LENGTH_SHORT).show();
            }
            setIntent(new Intent());
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) checkClipboard();
    }

    private void checkClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip()) return;
        ClipData data = cm.getPrimaryClip();
        if (data == null || data.getItemCount() == 0) return;
        CharSequence text = data.getItemAt(0).coerceToText(this);
        final String url = extractUrl(text == null ? null : text.toString());
        if (url == null || url.equals(lastClipUrl) || hasUrl(url)) return;
        lastClipUrl = url;
        String shown = url.length() > 60 ? url.substring(0, 60) + "…" : url;
        Snackbar.make(root, "Link disalin: " + shown, Snackbar.LENGTH_LONG)
                .setAction("Download", v -> addDownload(url))
                .show();
    }

    private static String extractUrl(String text) {
        if (text == null) return null;
        Matcher m = URL_PATTERN.matcher(text);
        return m.find() ? m.group() : null;
    }

    private boolean hasUrl(String url) {
        for (DownloadItem i : items) if (i.url.equals(url)) return true;
        return false;
    }

    private void showAddDialog(String prefill) {
        final EditText input = new EditText(this);
        input.setHint(R.string.add_hint);
        input.setSingleLine(true);
        input.setText(prefill);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        androidx.appcompat.widget.LinearLayoutCompat box =
                new androidx.appcompat.widget.LinearLayoutCompat(this);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(input, new androidx.appcompat.widget.LinearLayoutCompat.LayoutParams(
                androidx.appcompat.widget.LinearLayoutCompat.LayoutParams.MATCH_PARENT,
                androidx.appcompat.widget.LinearLayoutCompat.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this)
                .setTitle(R.string.add_title)
                .setView(box)
                .setPositiveButton(R.string.start, (d, w) -> addDownload(input.getText().toString().trim()))
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void addDownload(String url) {
        String valid = extractUrl(url);
        if (valid == null) {
            Toast.makeText(this, "Link harus diawali http:// atau https://", Toast.LENGTH_SHORT).show();
            return;
        }
        if (hasUrl(valid)) {
            Toast.makeText(this, "Link ini sudah ada di daftar", Toast.LENGTH_SHORT).show();
            return;
        }
        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) dir = new File(getFilesDir(), "downloads");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();

        DownloadItem item = new DownloadItem();
        item.url = valid;
        item.name = uniqueName(dir, guessName(valid));
        item.path = new File(dir, item.name).getAbsolutePath();
        items.add(0, item);
        adapter.notifyItemInserted(0);
        updateEmpty();
        startDownload(item);
    }

    private String guessName(String url) {
        String name = null;
        try {
            name = Uri.parse(url).getLastPathSegment();
            if (name != null) name = URLDecoder.decode(name, "UTF-8");
        } catch (Exception ignored) {
            // fall through to default
        }
        if (name == null) name = "";
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return name.isEmpty() ? "download" : name;
    }

    private String uniqueName(File dir, String name) {
        String base = name;
        String ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) {
            base = name.substring(0, dot);
            ext = name.substring(dot);
        }
        String candidate = name;
        int n = 1;
        while (new File(dir, candidate).exists() || nameUsed(candidate)) {
            candidate = base + " (" + n++ + ")" + ext;
        }
        return candidate;
    }

    private boolean nameUsed(String name) {
        for (DownloadItem i : items) if (i.name.equals(name)) return true;
        return false;
    }

    private void startDownload(DownloadItem item) {
        item.error = null;
        item.status = FileDownloadStatus.pending;
        BaseDownloadTask task = FileDownloader.getImpl().create(item.url)
                .setPath(item.path)
                .setAutoRetryTimes(3)
                .setCallbackProgressMinInterval(500)
                .setListener(listener);
        item.id = task.start();
        refresh(item);
    }

    private final FileDownloadLargeFileListener listener = new FileDownloadLargeFileListener() {
        @Override
        protected void pending(BaseDownloadTask task, long soFarBytes, long totalBytes) {
            update(task, FileDownloadStatus.pending, soFarBytes, totalBytes, null);
        }

        @Override
        protected void progress(BaseDownloadTask task, long soFarBytes, long totalBytes) {
            DownloadItem item = find(task);
            if (item != null) item.speed = task.getSpeed();
            update(task, FileDownloadStatus.progress, soFarBytes, totalBytes, null);
        }

        @Override
        protected void paused(BaseDownloadTask task, long soFarBytes, long totalBytes) {
            DownloadItem item = find(task);
            if (item != null) item.speed = 0;
            update(task, FileDownloadStatus.paused, soFarBytes, totalBytes, null);
            DownloadStore.save(MainActivity.this, items);
        }

        @Override
        protected void completed(BaseDownloadTask task) {
            DownloadItem item = find(task);
            if (item == null) return;
            item.status = FileDownloadStatus.completed;
            item.speed = 0;
            item.total = task.getLargeFileTotalBytes();
            item.soFar = item.total;
            refresh(item);
            DownloadStore.save(MainActivity.this, items);
            moveToDownloads(item);
        }

        @Override
        protected void error(BaseDownloadTask task, Throwable e) {
            DownloadItem item = find(task);
            if (item == null) return;
            item.status = FileDownloadStatus.error;
            item.speed = 0;
            item.error = e == null ? "Terjadi kesalahan" : String.valueOf(e.getMessage());
            refresh(item);
            DownloadStore.save(MainActivity.this, items);
        }

        @Override
        protected void warn(BaseDownloadTask task) {
            // Same task already running; nothing to do.
        }
    };

    private DownloadItem find(BaseDownloadTask task) {
        for (DownloadItem i : items) if (i.id == task.getId()) return i;
        return null;
    }

    private void update(BaseDownloadTask task, byte status, long soFar, long total, String error) {
        DownloadItem item = find(task);
        if (item == null) return;
        item.status = status;
        item.soFar = soFar;
        item.total = total;
        item.error = error;
        refresh(item);
    }

    private void refresh(DownloadItem item) {
        int index = items.indexOf(item);
        if (index >= 0) adapter.notifyItemChanged(index);
    }

    private void updateEmpty() {
        emptyView.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    // ---- row actions ----

    @Override
    public void onAction(DownloadItem item) {
        if (item.isCompleted()) {
            if (item.savedUri != null) {
                openFile(item);
            } else {
                moveToDownloads(item);
            }
        } else if (item.isRunning()) {
            FileDownloader.getImpl().pause(item.id);
        } else {
            startDownload(item);
        }
    }

    @Override
    public void onDelete(final DownloadItem item) {
        new AlertDialog.Builder(this)
                .setTitle("Hapus dari daftar?")
                .setMessage(item.savedUri != null
                        ? "File yang sudah tersimpan di folder Download tidak ikut dihapus."
                        : "File yang belum selesai akan dihapus.")
                .setPositiveButton("Hapus", (d, w) -> {
                    FileDownloader.getImpl().pause(item.id);
                    FileDownloader.getImpl().clear(item.id, item.path);
                    //noinspection ResultOfMethodCallIgnored
                    new File(item.path).delete();
                    int index = items.indexOf(item);
                    if (index >= 0) {
                        items.remove(index);
                        adapter.notifyItemRemoved(index);
                    }
                    updateEmpty();
                    DownloadStore.save(this, items);
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void openFile(DownloadItem item) {
        try {
            Uri uri = Uri.parse(item.savedUri);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, mimeOf(item.name));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Tidak ada aplikasi untuk membuka file ini. "
                    + "Cari di folder Download.", Toast.LENGTH_LONG).show();
        }
    }

    private static String mimeOf(String name) {
        int dot = name.lastIndexOf('.');
        if (dot >= 0) {
            String mime = MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(name.substring(dot + 1).toLowerCase(Locale.ROOT));
            if (mime != null) return mime;
        }
        return "application/octet-stream";
    }

    // ---- save to the public Download folder (Android 10+) ----

    private void moveToDownloads(final DownloadItem item) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || item.moving) return;
        item.moving = true;
        item.error = null;
        refresh(item);

        final ContentResolver resolver = getContentResolver();
        new Thread(() -> {
            Uri uri = null;
            String err = null;
            try {
                File src = new File(item.path);
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, item.name);
                values.put(MediaStore.Downloads.MIME_TYPE, mimeOf(item.name));
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IOException("Gagal membuat file di Download");
                try (InputStream in = new FileInputStream(src);
                     OutputStream out = resolver.openOutputStream(uri)) {
                    if (out == null) throw new IOException("Gagal menulis file");
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                resolver.update(uri, values, null, null);
                //noinspection ResultOfMethodCallIgnored
                src.delete();
            } catch (Exception e) {
                err = e.getMessage() == null ? "Gagal menyimpan" : e.getMessage();
                if (uri != null) {
                    try {
                        resolver.delete(uri, null, null);
                    } catch (Exception ignored) {
                        // best effort cleanup
                    }
                    uri = null;
                }
            }
            final Uri savedUri = uri;
            final String error = err;
            runOnUiThread(() -> {
                item.moving = false;
                if (savedUri != null) {
                    item.savedUri = savedUri.toString();
                    Toast.makeText(this, item.name + " tersimpan di folder Download",
                            Toast.LENGTH_SHORT).show();
                } else {
                    item.error = error;
                }
                refresh(item);
                DownloadStore.save(this, items);
            });
        }).start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        DownloadStore.save(this, items);
    }
}
