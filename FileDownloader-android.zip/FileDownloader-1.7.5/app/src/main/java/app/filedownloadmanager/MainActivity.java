package app.filedownloadmanager;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.liulishuo.filedownloader.BaseDownloadTask;
import com.liulishuo.filedownloader.FileDownloadLargeFileListener;
import com.liulishuo.filedownloader.FileDownloader;
import com.liulishuo.filedownloader.model.FileDownloadStatus;
import com.liulishuo.filedownloader.util.FileDownloadUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements DownloadAdapter.Callback {

    // Some servers (e.g. behind Cloudflare) refuse the library's default "FileDownloader/x" agent.
    private static final String DEFAULT_UA = "Mozilla/5.0 (Linux; Android 10; SM-N960F) "
            + "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36";
    private static final Pattern HTTP_CODE = Pattern.compile("response code error: (\\d{3})");
    private static final Pattern URL_PATTERN = Pattern.compile("https?://\\S+");

    private List<DownloadItem> items;
    private DownloadAdapter adapter;
    private View root;
    private View emptyView;
    private String lastClipUrl;
    private String pendingMime;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable poller = new Runnable() {
        @Override
        public void run() {
            pollSegments();
            handler.postDelayed(this, 1500);
        }
    };
    private final ActivityResultLauncher<Intent> browserLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                Intent d = result.getData();
                if (result.getResultCode() != RESULT_OK || d == null) return;
                if (d.hasExtra("refresh_id")) {
                    int rid = d.getIntExtra("refresh_id", 0);
                    for (DownloadItem target : items) {
                        if (target.id == rid && d.getStringExtra("url") != null) {
                            target.url = d.getStringExtra("url");
                            target.userAgent = d.getStringExtra("ua");
                            target.cookie = d.getStringExtra("cookie");
                            target.referer = d.getStringExtra("referer");
                            startDownload(target);
                            Toast.makeText(this, "Link diperbarui, melanjutkan download",
                                    Toast.LENGTH_SHORT).show();
                            break;
                        }
                    }
                    return;
                }
                pendingMime = d.getStringExtra("mime");
                showAddDialog(d.getStringExtra("url"), d.getStringExtra("name"),
                        d.getStringExtra("ua"), d.getStringExtra("cookie"),
                        d.getStringExtra("referer"));
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        root = findViewById(R.id.root);
        emptyView = findViewById(R.id.empty);
        RecyclerView list = findViewById(R.id.list);
        FloatingActionButton fab = findViewById(R.id.fab);

        items = DownloadStore.load(this);
        adapter = new DownloadAdapter(items, this);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
        fab.setOnClickListener(v -> showAddDialog(""));
        updateEmpty();
        Handoff.setReceiver(this::onHandoff);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        // Retry saving files that finished but were not yet moved to the Download folder.
        for (DownloadItem item : items) {
            if (item.isCompleted() && item.savedUri == null && sourceFile(item) != null) {
                moveToDownloads(item);
            }
        }

        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent != null && Intent.ACTION_VIEW.equals(intent.getAction())
                && intent.getDataString() != null) {
            String url = extractUrl(intent.getDataString());
            pendingMime = intent.getType();
            if (url != null) showAddDialog(url);
            setIntent(new Intent());
            return;
        }
        if (intent != null && Intent.ACTION_SEND.equals(intent.getAction())) {
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            String url = extractUrl(text);
            if (url != null) {
                showAddDialog(url);
            } else {
                Toast.makeText(this, "Tidak ada link yang valid", Toast.LENGTH_SHORT).show();
            }
            setIntent(new Intent());
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) checkClipboard();
    }

    private void checkClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip()) return;
        ClipData data = cm.getPrimaryClip();
        if (data == null || data.getItemCount() == 0) return;
        CharSequence text = data.getItemAt(0).coerceToText(this);
        final String url = extractUrl(text == null ? null : text.toString());
        if (url == null || url.equals(lastClipUrl) || hasUrl(url)) return;
        lastClipUrl = url;
        String shown = url.length() > 60 ? url.substring(0, 60) + "…" : url;
        Snackbar.make(root, "Link disalin: " + shown, Snackbar.LENGTH_LONG)
                .setAction("Download", v -> addDownload(url))
                .show();
    }

    private static String extractUrl(String text) {
        if (text == null) return null;
        Matcher m = URL_PATTERN.matcher(text);
        return m.find() ? m.group() : null;
    }

    private boolean hasUrl(String url) {
        for (DownloadItem i : items) if (i.url.equals(url)) return true;
        return false;
    }

    private void showAddDialog(String prefill) {
        showAddDialog(prefill, null, null, null, null);
    }

    private void showAddDialog(String prefill, String suggestedName,
                               final String ua, final String cookie, final String referer) {
        final EditText input = new EditText(this);
        input.setHint(R.string.add_hint);
        input.setSingleLine(true);
        input.setText(prefill);
        final EditText nameInput = new EditText(this);
        nameInput.setHint("Nama file (kosongkan = otomatis dari server)");
        nameInput.setSingleLine(true);
        if (suggestedName != null) nameInput.setText(suggestedName);

        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        androidx.appcompat.widget.LinearLayoutCompat box =
                new androidx.appcompat.widget.LinearLayoutCompat(this);
        box.setOrientation(androidx.appcompat.widget.LinearLayoutCompat.VERTICAL);
        box.setPadding(pad, pad / 2, pad, 0);
        androidx.appcompat.widget.LinearLayoutCompat.LayoutParams lp =
                new androidx.appcompat.widget.LinearLayoutCompat.LayoutParams(
                        androidx.appcompat.widget.LinearLayoutCompat.LayoutParams.MATCH_PARENT,
                        androidx.appcompat.widget.LinearLayoutCompat.LayoutParams.WRAP_CONTENT);
        box.addView(input, lp);
        box.addView(nameInput, lp);
        new AlertDialog.Builder(this)
                .setTitle(R.string.add_title)
                .setView(box)
                .setPositiveButton(R.string.start, (d, w) -> addDownload(
                        input.getText().toString().trim(),
                        nameInput.getText().toString().trim(), ua, cookie, referer))
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private static String sanitizeName(String name) {
        return name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
    }

    private void addDownload(String url) {
        addDownload(url, null, null, null, null);
    }

    private void addDownload(String url, String customName, String ua, String cookie,
                             String referer) {
        String valid = extractUrl(url);
        if (valid == null) {
            Toast.makeText(this, "Link harus diawali http:// atau https://", Toast.LENGTH_SHORT).show();
            return;
        }
        if (hasUrl(valid)) {
            Toast.makeText(this, "Link ini sudah ada di daftar", Toast.LENGTH_SHORT).show();
            return;
        }
        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) dir = new File(getFilesDir(), "downloads");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();

        File dlDir = new File(dir, "dl_" + System.currentTimeMillis()
                + "_c" + Settings.connections(this));
        //noinspection ResultOfMethodCallIgnored
        dlDir.mkdirs();

        DownloadItem item = new DownloadItem();
        item.url = valid;
        item.name = guessName(valid); // replaced by the server's filename once connected
        item.path = dlDir.getAbsolutePath(); // a folder; FileDownloader picks the filename
        item.mime = cleanMime(pendingMime);
        pendingMime = null;
        item.userAgent = ua;
        item.cookie = cookie;
        item.referer = referer;
        String custom = customName == null ? "" : sanitizeName(customName);
        if (!custom.isEmpty()) {
            item.name = custom;
            item.diskName = custom;
            item.customName = true;
        }
        items.add(0, item);
        adapter.notifyItemInserted(0);
        updateEmpty();
        startDownload(item);
    }

    private String guessName(String url) {
        String name = null;
        try {
            name = Uri.parse(url).getLastPathSegment();
            if (name != null) name = URLDecoder.decode(name, "UTF-8");
        } catch (Exception ignored) {
            // fall through to default
        }
        if (name == null) name = "";
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return name.isEmpty() ? "download" : name;
    }

    private String uniqueName(File dir, String name) {
        String base = name;
        String ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) {
            base = name.substring(0, dot);
            ext = name.substring(dot);
        }
        String candidate = name;
        int n = 1;
        while (new File(dir, candidate).exists() || nameUsed(candidate)) {
            candidate = base + " (" + n++ + ")" + ext;
        }
        return candidate;
    }

    private boolean nameUsed(String name) {
        for (DownloadItem i : items) if (i.name.equals(name)) return true;
        return false;
    }

    private void startDownload(DownloadItem item) {
        item.error = null;
        item.status = FileDownloadStatus.pending;
        BaseDownloadTask task = FileDownloader.getImpl().create(item.url)
                .setAutoRetryTimes(3)
                .setCallbackProgressMinInterval(500)
                .setListener(listener);
        if (item.diskName != null) {
            task.setPath(new File(item.path, item.diskName).getAbsolutePath(), false);
        } else {
            task.setPath(item.path, true);
        }
        task.addHeader("User-Agent", item.userAgent != null ? item.userAgent : DEFAULT_UA);
        if (item.cookie != null) task.addHeader("Cookie", item.cookie);
        task.addHeader("Referer", item.referer != null ? item.referer : originOf(item.url));
        item.lastTick = SystemClock.elapsedRealtime();
        item.id = task.start();
        refresh(item);
    }

    private final FileDownloadLargeFileListener listener = new FileDownloadLargeFileListener() {
        @Override
        protected void pending(BaseDownloadTask task, long soFarBytes, long totalBytes) {
            update(task, FileDownloadStatus.pending, soFarBytes, totalBytes, null);
        }

        @Override
        protected void connected(BaseDownloadTask task, String etag, boolean isContinue,
                                 long soFarBytes, long totalBytes) {
            DownloadItem item = find(task);
            if (item == null) return;
            applyServerName(item, task);
            item.status = FileDownloadStatus.connected;
            item.soFar = soFarBytes;
            item.total = totalBytes;
            refresh(item);
        }

        @Override
        protected void progress(BaseDownloadTask task, long soFarBytes, long totalBytes) {
            DownloadItem item = find(task);
            if (item != null) item.speed = task.getSpeed();
            update(task, FileDownloadStatus.progress, soFarBytes, totalBytes, null);
        }

        @Override
        protected void paused(BaseDownloadTask task, long soFarBytes, long totalBytes) {
            DownloadItem item = find(task);
            if (item != null) item.speed = 0;
            update(task, FileDownloadStatus.paused, soFarBytes, totalBytes, null);
            DownloadStore.save(MainActivity.this, items);
        }

        @Override
        protected void completed(BaseDownloadTask task) {
            DownloadItem item = find(task);
            if (item == null) return;
            accrue(item, false);
            item.status = FileDownloadStatus.completed;
            item.speed = 0;
            item.segments = null;
            item.targetPath = task.getTargetFilePath();
            applyServerName(item, task);
            fixExtension(item);
            item.total = task.getLargeFileTotalBytes();
            item.soFar = item.total;
            refresh(item);
            DownloadStore.save(MainActivity.this, items);
            moveToDownloads(item);
        }

        @Override
        protected void error(BaseDownloadTask task, Throwable e) {
            DownloadItem item = find(task);
            if (item == null) return;
            accrue(item, false);
            item.status = FileDownloadStatus.error;
            item.speed = 0;
            item.error = friendlyError(item, e);
            refresh(item);
            DownloadStore.save(MainActivity.this, items);
        }

        @Override
        protected void warn(BaseDownloadTask task) {
            // Same task already running; nothing to do.
        }
    };

    private static String originOf(String url) {
        Uri u = Uri.parse(url);
        return u.getScheme() + "://" + u.getHost() + "/";
    }

    private static String friendlyError(DownloadItem item, Throwable e) {
        item.errorCode = 0;
        String msg = e == null ? null : e.getMessage();
        if (msg == null) return "Terjadi kesalahan";
        Matcher m = HTTP_CODE.matcher(msg);
        if (m.find()) {
            int code = Integer.parseInt(m.group(1));
            item.errorCode = code;
            switch (code) {
                case 401:
                case 403:
                    return "Ditolak server (" + code + "). Link kedaluwarsa atau butuh login. "
                            + "Ketuk \"Perbarui link\".";
                case 404:
                case 410:
                    return "File tidak ditemukan (" + code + "). Link mungkin kedaluwarsa. "
                            + "Ketuk \"Perbarui link\".";
                case 429:
                    return "Terlalu banyak permintaan (429). Kurangi jumlah bagian di "
                            + "Pengaturan, tunggu sebentar, lalu ketuk Lanjut.";
                default:
                    return "Server menjawab error " + code + ".";
            }
        }
        return msg.length() > 140 ? msg.substring(0, 140) + "…" : msg;
    }

    /** Use the filename from the server (Content-Disposition) when there is one. */
    private void applyServerName(DownloadItem item, BaseDownloadTask task) {
        if (item.customName) return;
        String fn = task.getFilename();
        if (fn != null && !fn.isEmpty()
                && !fn.equals(FileDownloadUtils.generateFileName(item.url))) {
            item.name = fn;
        }
    }

    private static String cleanMime(String mime) {
        if (mime == null) return null;
        mime = mime.toLowerCase(Locale.ROOT);
        if (mime.contains("*") || mime.equals("application/octet-stream")) return null;
        return mime;
    }

    /** Make sure the name has an extension: use the browser's mime type, else sniff the file. */
    private void fixExtension(DownloadItem item) {
        if (item.customName) return;
        if (item.name.lastIndexOf('.') > 0) return;
        String ext = null;
        if (item.mime != null) {
            ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(item.mime);
        }
        File f = sourceFile(item);
        if (ext == null && f != null) ext = sniffExtension(f);
        if (ext != null) item.name = item.name + "." + ext;
    }

    private static String sniffExtension(File f) {
        byte[] b = new byte[12];
        try (InputStream in = new FileInputStream(f)) {
            if (in.read(b) < 8) return null;
        } catch (IOException e) {
            return null;
        }
        String head = new String(b, java.nio.charset.StandardCharsets.ISO_8859_1);
        if (head.startsWith("%PDF")) return "pdf";
        if (head.startsWith("PK\u0003\u0004")) return "zip";
        if (head.startsWith("\u0089PNG")) return "png";
        if (head.startsWith("GIF8")) return "gif";
        if (head.startsWith("Rar!")) return "rar";
        if (head.startsWith("ID3")) return "mp3";
        if (head.startsWith("OggS")) return "ogg";
        if (head.startsWith("7z\u00bc\u00af")) return "7z";
        if (head.substring(4, 8).equals("ftyp")) return "mp4";
        if ((b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xD8) return "jpg";
        return null;
    }

    /** The finished file on disk, or null when it is gone. */
    private static File sourceFile(DownloadItem item) {
        if (item.targetPath == null) return null;
        File f = new File(item.targetPath);
        return f.isFile() ? f : null;
    }

    private static void deleteRecursive(File f) {
        File[] children = f.listFiles();
        if (children != null) for (File c : children) deleteRecursive(c);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    private DownloadItem find(BaseDownloadTask task) {
        for (DownloadItem i : items) if (i.id == task.getId()) return i;
        return null;
    }

    private static void accrue(DownloadItem item, boolean keepRunning) {
        long now = SystemClock.elapsedRealtime();
        if (item.lastTick > 0) item.elapsedMs += now - item.lastTick;
        item.lastTick = keepRunning ? now : 0;
    }

    private void update(BaseDownloadTask task, byte status, long soFar, long total, String error) {
        DownloadItem item = find(task);
        if (item == null) return;
        accrue(item, status != FileDownloadStatus.paused);
        item.status = status;
        item.soFar = soFar;
        item.total = total;
        item.error = error;
        refresh(item);
    }

    private void refresh(DownloadItem item) {
        int index = items.indexOf(item);
        if (index >= 0) adapter.notifyItemChanged(index);
    }

    private void updateEmpty() {
        emptyView.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    // ---- row actions ----

    @Override
    public void onAction(DownloadItem item) {
        if (item.isCompleted()) {
            if (item.savedUri != null) {
                openFile(item);
            } else {
                moveToDownloads(item);
            }
        } else if (item.isRunning()) {
            FileDownloader.getImpl().pause(item.id);
        } else if (item.needsNewLink()) {
            Intent i = new Intent(this, BrowserActivity.class);
            i.putExtra("start", item.referer != null ? item.referer : originOf(item.url));
            i.putExtra("refresh_id", item.id);
            browserLauncher.launch(i);
        } else {
            startDownload(item);
        }
    }

    @Override
    public void onDelete(final DownloadItem item) {
        new AlertDialog.Builder(this)
                .setTitle("Hapus dari daftar?")
                .setMessage(item.savedUri != null
                        ? "File yang sudah tersimpan di folder Download tidak ikut dihapus."
                        : "File yang belum selesai akan dihapus.")
                .setPositiveButton("Hapus", (d, w) -> {
                    FileDownloader.getImpl().pause(item.id);
                    FileDownloader.getImpl().clear(item.id,
                            item.targetPath != null ? item.targetPath : item.path);
                    deleteRecursive(new File(item.path));
                    int index = items.indexOf(item);
                    if (index >= 0) {
                        items.remove(index);
                        adapter.notifyItemRemoved(index);
                    }
                    updateEmpty();
                    DownloadStore.save(this, items);
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void openFile(DownloadItem item) {
        try {
            Uri uri = Uri.parse(item.savedUri);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, mimeOf(item.name));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Tidak ada aplikasi untuk membuka file ini. "
                    + "Cari di folder Download.", Toast.LENGTH_LONG).show();
        }
    }

    private static String mimeOf(String name) {
        int dot = name.lastIndexOf('.');
        if (dot >= 0) {
            String mime = MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(name.substring(dot + 1).toLowerCase(Locale.ROOT));
            if (mime != null) return mime;
        }
        return "application/octet-stream";
    }

    // ---- save to the public Download folder (Android 10+) ----

    private void moveToDownloads(final DownloadItem item) {
        final String treeStr = Settings.treeUri(this);
        if ((Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && treeStr == null) || item.moving) {
            return;
        }
        item.moving = true;
        item.error = null;
        refresh(item);

        final ContentResolver resolver = getContentResolver();
        new Thread(() -> {
            Uri uri = null;
            String err = null;
            try {
                File src = sourceFile(item);
                if (src == null) throw new IOException("File sumber tidak ditemukan");
                if (treeStr != null) {
                    // Folder chosen by the user (Storage Access Framework).
                    DocumentFile tree = DocumentFile.fromTreeUri(this, Uri.parse(treeStr));
                    if (tree == null || !tree.canWrite()) {
                        throw new IOException("Folder tujuan tidak bisa ditulis. "
                                + "Pilih ulang di Pengaturan.");
                    }
                    DocumentFile out = tree.createFile(mimeOf(item.name), item.name);
                    if (out == null) throw new IOException("Gagal membuat file di folder tujuan");
                    uri = out.getUri();
                    copy(src, resolver, uri);
                } else {
                    // Default: the public Download folder (Android 10+).
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, item.name);
                    values.put(MediaStore.Downloads.MIME_TYPE, mimeOf(item.name));
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IOException("Gagal membuat file di Download");
                    copy(src, resolver, uri);
                    values.clear();
                    values.put(MediaStore.Downloads.IS_PENDING, 0);
                    resolver.update(uri, values, null, null);
                }
                deleteRecursive(new File(item.path));
            } catch (Exception e) {
                err = e.getMessage() == null ? "Gagal menyimpan" : e.getMessage();
                if (uri != null) {
                    try {
                        if (treeStr != null) DocumentsContract.deleteDocument(resolver, uri);
                        else resolver.delete(uri, null, null);
                    } catch (Exception ignored) {
                        // best effort cleanup
                    }
                    uri = null;
                }
            }
            final Uri savedUri = uri;
            final String error = err;
            runOnUiThread(() -> {
                item.moving = false;
                if (savedUri != null) {
                    item.savedUri = savedUri.toString();
                    Toast.makeText(this, item.name + " tersimpan", Toast.LENGTH_SHORT).show();
                } else {
                    item.error = error;
                }
                refresh(item);
                DownloadStore.save(this, items);
            });
        }).start();
    }

    private static void copy(File src, ContentResolver resolver, Uri uri) throws IOException {
        try (InputStream in = new FileInputStream(src);
             OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) throw new IOException("Gagal menulis file");
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    // ---- menu ----

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(Menu.NONE, 2, Menu.NONE, "Browser")
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        menu.add(Menu.NONE, 1, Menu.NONE, "Pengaturan")
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 1) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        if (menuItem.getItemId() == 2) {
            browserLauncher.launch(new Intent(this, BrowserActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    // ---- rename ----

    @Override
    public void onRename(final DownloadItem item) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(item.name);
        input.setSelection(item.name.length());
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        androidx.appcompat.widget.LinearLayoutCompat box =
                new androidx.appcompat.widget.LinearLayoutCompat(this);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(input, new androidx.appcompat.widget.LinearLayoutCompat.LayoutParams(
                androidx.appcompat.widget.LinearLayoutCompat.LayoutParams.MATCH_PARENT,
                androidx.appcompat.widget.LinearLayoutCompat.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this)
                .setTitle("Ganti nama file")
                .setView(box)
                .setPositiveButton("Simpan", (d, w) -> {
                    String newName = sanitizeName(input.getText().toString());
                    if (newName.isEmpty() || newName.equals(item.name)) return;
                    renameItem(item, newName);
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void renameItem(final DownloadItem item, final String newName) {
        if (item.moving) {
            Toast.makeText(this, "Tunggu sampai file selesai disimpan", Toast.LENGTH_SHORT).show();
            return;
        }
        if (item.savedUri == null) {
            // Not saved yet: the new name is used when the file is saved.
            item.name = newName;
            item.customName = true;
            refresh(item);
            DownloadStore.save(this, items);
            return;
        }
        final ContentResolver resolver = getContentResolver();
        final Uri old = Uri.parse(item.savedUri);
        new Thread(() -> {
            Uri result = null;
            try {
                if ("media".equals(old.getAuthority())) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, newName);
                    if (resolver.update(old, v, null, null) > 0) result = old;
                } else {
                    result = DocumentsContract.renameDocument(resolver, old, newName);
                }
            } catch (Exception ignored) {
                // reported below
            }
            final Uri renamed = result;
            runOnUiThread(() -> {
                if (renamed != null) {
                    item.name = newName;
                    item.customName = true;
                    item.savedUri = renamed.toString();
                } else {
                    Toast.makeText(this, "Gagal mengganti nama file", Toast.LENGTH_SHORT).show();
                }
                refresh(item);
                DownloadStore.save(this, items);
            });
        }).start();
    }

    // ---- per-part progress, read from the download engine's database ----

    private void pollSegments() {
        boolean any = false;
        for (DownloadItem i : items) if (!i.isCompleted() && i.id != 0) any = true;
        if (!any) return;
        File dbFile = getDatabasePath("filedownloader.db");
        if (!dbFile.exists()) return;
        SQLiteDatabase db = null;
        try {
            db = SQLiteDatabase.openDatabase(dbFile.getPath(), null,
                    SQLiteDatabase.OPEN_READONLY);
            for (DownloadItem item : items) {
                if (item.isCompleted() || item.id == 0) continue;
                float[] seg = null;
                try (Cursor c = db.rawQuery("SELECT startOffset, currentOffset, endOffset "
                                + "FROM filedownloaderConnection WHERE id=? "
                                + "ORDER BY connectionIndex",
                        new String[]{String.valueOf(item.id)})) {
                    if (c.getCount() > 1) {
                        seg = new float[c.getCount()];
                        int k = 0;
                        while (c.moveToNext()) {
                            long start = c.getLong(0);
                            long cur = c.getLong(1);
                            long end = c.getLong(2);
                            if (end <= 0) end = item.total - 1; // last part runs to the end
                            long len = end - start + 1;
                            seg[k++] = len <= 0 ? 0f
                                    : Math.max(0f, Math.min(1f, (float) (cur - start) / len));
                        }
                    }
                }
                int parts = seg == null ? 0 : seg.length;
                if (parts != item.parts || !java.util.Arrays.equals(seg, item.segments)) {
                    item.segments = seg;
                    item.parts = parts;
                    refresh(item);
                }
            }
        } catch (Exception ignored) {
            // database busy or not created yet; try again on the next tick
        } finally {
            if (db != null) db.close();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(poller);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(poller);
    }

    /** A download started from the in-app browser (it stays open meanwhile). */
    private void onHandoff(Handoff.Request r) {
        pendingMime = r.mime;
        addDownload(r.url, r.name, r.ua, r.cookie, r.referer);
    }

    @Override
    protected void onDestroy() {
        Handoff.setReceiver(null);
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        super.onStop();
        DownloadStore.save(this, items);
    }
}
