package app.filedownloadmanager;

import android.content.Context;
import android.net.Uri;
import android.widget.Toast;

import java.util.Locale;

/**
 * YouTube only allows downloads through its own Download button, so this app never downloads
 * YouTube videos and never sniffs YouTube's streams. It just says so when asked.
 */
final class YouTubeHelper {

    private static final String[] VIDEO_PATHS = {
            "/watch", "/shorts/", "/live/", "/embed/", "/playlist", "/clip/"
    };

    private YouTubeHelper() {
    }

    private static boolean isYoutubeHost(String h) {
        return h.equals("youtube.com") || h.endsWith(".youtube.com")
                || h.equals("youtube-nocookie.com") || h.endsWith(".youtube-nocookie.com");
    }

    /**
     * True for YouTube video pages and YouTube's own stream addresses. Official download links
     * that YouTube shows (for example Studio downloads of your own uploads) are not matched.
     */
    static boolean isRestrictedUrl(String url) {
        if (url == null || url.isEmpty()) return false;
        Uri u = Uri.parse(url);
        String host = u.getHost();
        if (host == null) return false;
        host = host.toLowerCase(Locale.ROOT);
        if (host.equals("googlevideo.com") || host.endsWith(".googlevideo.com")) return true;
        if (host.equals("youtu.be") || host.endsWith(".youtu.be")) return true;
        if (!isYoutubeHost(host)) return false;
        String path = u.getPath();
        if (path == null) return false;
        for (String p : VIDEO_PATHS) {
            if (path.startsWith(p)) return true;
        }
        return false;
    }

    static void explain(Context c) {
        Toast.makeText(c, "Video YouTube tidak bisa diunduh di aplikasi ini. "
                + "Gunakan tombol Download resmi di aplikasi YouTube.", Toast.LENGTH_LONG).show();
    }
}
