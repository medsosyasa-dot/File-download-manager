package app.filedownloadmanager;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import java.util.Locale;

/**
 * YouTube only allows downloads through its own Download button (and for a channel owner's own
 * uploads). This app does not download YouTube videos and never tries to get around YouTube's
 * protections; it explains the allowed options instead.
 */
final class YouTubeHelper {

    private static final String[] VIDEO_PATHS = {
            "/watch", "/shorts/", "/live/", "/embed/", "/playlist", "/clip/"
    };

    private static final String MESSAGE =
            "Aplikasi ini tidak menyediakan unduhan untuk video YouTube.\n\n"
                    + "YouTube hanya mengizinkan unduhan lewat tombol Download miliknya sendiri, "
                    + "dan tidak ada jalur resmi bagi aplikasi lain untuk mengambil video orang "
                    + "lain. Aplikasi ini juga tidak mencoba menembus proteksi atau mengambil "
                    + "token YouTube.\n\n"
                    + "Cara resmi yang tersedia:\n"
                    + "1. Tonton offline: tombol Download di aplikasi YouTube atau YouTube Music "
                    + "(YouTube Premium). Filenya hanya bisa diputar di aplikasi YouTube.\n"
                    + "2. Video yang kamu unggah sendiri: YouTube Studio, menu Konten, lalu "
                    + "Download. Untuk semuanya sekaligus, pakai Google Takeout.\n\n"
                    + "Pilih salah satu:";

    private YouTubeHelper() {
    }

    private static boolean isYoutubeHost(String h) {
        return h.equals("youtube.com") || h.endsWith(".youtube.com")
                || h.equals("youtu.be") || h.endsWith(".youtu.be")
                || h.equals("youtube-nocookie.com") || h.endsWith(".youtube-nocookie.com");
    }

    /**
     * True for YouTube video pages and YouTube's own stream addresses. Official download links
     * that YouTube shows (for example Studio downloads of your own uploads) are not matched.
     */
    static boolean isRestrictedUrl(String url) {
        if (url == null || url.isEmpty()) return false;
        Uri u = Uri.parse(url);
        String host = u.getHost();
        if (host == null) return false;
        host = host.toLowerCase(Locale.ROOT);
        if (host.equals("googlevideo.com") || host.endsWith(".googlevideo.com")) return true;
        if (host.equals("youtu.be") || host.endsWith(".youtu.be")) return true;
        if (!isYoutubeHost(host)) return false;
        String path = u.getPath();
        if (path == null) return false;
        for (String p : VIDEO_PATHS) {
            if (path.startsWith(p)) return true;
        }
        return false;
    }

    static void showInfo(final Activity a, final String url) {
        int px = (int) a.getResources().getDisplayMetrics().density;
        ScrollView scroll = new ScrollView(a);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(20 * px, 8 * px, 20 * px, 0);
        scroll.addView(box);
        TextView msg = new TextView(a);
        msg.setText(MESSAGE);
        msg.setTextSize(14);
        box.addView(msg);

        final AlertDialog dialog = new AlertDialog.Builder(a)
                .setTitle("Video YouTube")
                .setView(scroll)
                .setNegativeButton("Tutup", null)
                .create();
        addAction(a, box, dialog, "Buka di aplikasi YouTube", () -> openInYoutubeApp(a, url));
        addAction(a, box, dialog, "Video milik saya: YouTube Studio",
                () -> openExternal(a, "https://studio.youtube.com"));
        addAction(a, box, dialog, "Semua video milik saya: Google Takeout",
                () -> openExternal(a, "https://takeout.google.com"));
        addAction(a, box, dialog, "Salin tautan video", () -> copyLink(a, url));
        dialog.show();
    }

    private static void addAction(Activity a, LinearLayout box, final AlertDialog dialog,
                                  String label, final Runnable action) {
        Button b = new Button(a, null, android.R.attr.borderlessButtonStyle);
        b.setText(label);
        b.setAllCaps(false);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setOnClickListener(v -> {
            dialog.dismiss();
            action.run();
        });
        box.addView(b, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private static void openInYoutubeApp(Activity a, String url) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url))
                .setPackage("com.google.android.youtube");
        try {
            a.startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(a, "Aplikasi YouTube belum terpasang", Toast.LENGTH_SHORT).show();
            openExternal(a, "market://details?id=com.google.android.youtube");
        }
    }

    private static void openExternal(Activity a, String url) {
        try {
            a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(a, "Tidak ada aplikasi untuk membuka tautan ini", Toast.LENGTH_SHORT)
                    .show();
        }
    }

    private static void copyLink(Activity a, String url) {
        ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("Tautan YouTube", url));
            Toast.makeText(a, "Tautan disalin", Toast.LENGTH_SHORT).show();
        }
    }
}
