package app.filedownloadmanager;

import android.content.Context;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

final class DownloadStore {
    private static final String PREFS = "downloads";
    private static final String KEY = "items";

    private DownloadStore() {
    }

    static List<DownloadItem> load(Context c) {
        List<DownloadItem> list = new ArrayList<>();
        String s = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null);
        if (s == null) return list;
        try {
            JSONArray a = new JSONArray(s);
            for (int i = 0; i < a.length(); i++) {
                list.add(DownloadItem.fromJson(a.getJSONObject(i)));
            }
        } catch (Exception ignored) {
            // Corrupt data: start with what we managed to read.
        }
        return list;
    }

    static void save(Context c, List<DownloadItem> items) {
        try {
            JSONArray a = new JSONArray();
            for (DownloadItem i : items) a.put(i.toJson());
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(KEY, a.toString()).apply();
        } catch (Exception ignored) {
            // Nothing sensible to do; list stays in memory.
        }
    }
}
