(function () {
  'use strict';
  if (window.__fdmAdblock) return;
  window.__fdmAdblock = true;

  // ---------- cosmetic rules: hide common ad containers on every site ----------
  var CSS = [
    'ins.adsbygoogle', '[id^="google_ads_iframe"]', '[id^="div-gpt-ad"]',
    'iframe[src*="doubleclick.net"]', 'iframe[src*="googlesyndication.com"]',
    'iframe[src*="adservice.google"]', '[aria-label="Advertisement"]',
    '.adsbygoogle', '.ad-banner', '.ad-container', '.advert', '.banner-ads'
  ].join(',') + '{display:none!important;}';

  var onYoutube = /(^|\.)youtube\.com$/.test(location.hostname);
  if (onYoutube) {
    CSS += [
      '#player-ads', '#masthead-ad', 'ytd-ad-slot-renderer', 'ytd-display-ad-renderer',
      'ytd-promoted-sparkles-web-renderer', 'ytd-banner-promo-renderer',
      'ytd-in-feed-ad-layout-renderer', 'ytm-promoted-sparkles-web-renderer',
      'ytm-companion-slot', 'ytm-promoted-video-renderer', '.ytp-ad-overlay-container',
      '.ytp-ad-image-overlay', '.video-ads', 'ad-slot-renderer',
      '[class*="ytm-ad-slot"]', 'ytd-rich-item-renderer:has(ytd-ad-slot-renderer)'
    ].join(',') + '{display:none!important;}';
  }

  function addCss() {
    var s = document.createElement('style');
    s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }
  if (document.documentElement) addCss();
  else document.addEventListener('DOMContentLoaded', addCss);

  if (!onYoutube) return;

  // ---------- YouTube: remove ad data from the player response ----------
  var AD_KEYS = ['adPlacements', 'playerAds', 'adSlots', 'adBreakHeartbeatParams'];
  function strip(o) {
    if (o && typeof o === 'object') {
      for (var i = 0; i < AD_KEYS.length; i++) {
        if (AD_KEYS[i] in o) {
          try { delete o[AD_KEYS[i]]; } catch (e) { /* ignore */ }
        }
      }
    }
    return o;
  }

  var origParse = JSON.parse;
  JSON.parse = function () {
    return strip(origParse.apply(this, arguments));
  };

  try {
    var initial;
    Object.defineProperty(window, 'ytInitialPlayerResponse', {
      configurable: true,
      get: function () { return initial; },
      set: function (v) { initial = strip(v); }
    });
  } catch (e) { /* ignore */ }

  var origFetch = window.fetch;
  if (origFetch) {
    window.fetch = function () {
      var args = arguments;
      return origFetch.apply(this, args).then(function (resp) {
        try {
          var u = args[0] && args[0].url ? args[0].url : String(args[0]);
          if (u.indexOf('/youtubei/v1/player') !== -1 || u.indexOf('/youtubei/v1/next') !== -1) {
            return resp.clone().text().then(function (t) {
              try {
                var j = strip(origParse(t));
                return new Response(JSON.stringify(j), {
                  status: resp.status, statusText: resp.statusText, headers: resp.headers
                });
              } catch (e) { return resp; }
            });
          }
        } catch (e) { /* ignore */ }
        return resp;
      });
    };
  }

  // ---------- YouTube: fallback, skip whatever ad still starts ----------
  setInterval(function () {
    var skip = document.querySelector(
      '.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-container button');
    if (skip) skip.click();
    var close = document.querySelector('.ytp-ad-overlay-close-button');
    if (close) close.click();
    var player = document.querySelector('.html5-video-player');
    if (player && player.classList.contains('ad-showing')) {
      var v = document.querySelector('video.html5-main-video') || document.querySelector('video');
      if (v && isFinite(v.duration) && v.duration > 0) {
        v.muted = true;
        v.currentTime = v.duration;
      }
    }
  }, 300);
})();
