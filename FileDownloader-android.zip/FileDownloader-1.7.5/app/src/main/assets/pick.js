(function () {
  if (window.__fdmPicking) return;
  window.__fdmPicking = true;

  var finished = false;
  var last = null;
  var box = document.createElement('div');
  box.style.cssText = 'position:fixed;z-index:2147483647;border:2px solid #00D9C0;' +
    'background:rgba(0,217,192,.25);pointer-events:none;left:0;top:0;width:0;height:0;';
  var tip = document.createElement('div');
  tip.style.cssText = 'position:fixed;z-index:2147483647;left:0;right:0;top:0;padding:10px;' +
    'background:#00D9C0;color:#000;font:14px sans-serif;text-align:center;pointer-events:none;';
  tip.textContent = 'Sentuh dan geser ke iklan, lepas untuk memblokirnya';
  document.documentElement.appendChild(box);
  document.documentElement.appendChild(tip);

  function esc(s) { return (window.CSS && CSS.escape) ? CSS.escape(s) : s.replace(/[^\w-]/g, '\\$&'); }

  function selectorFor(el) {
    if (el.id && document.querySelectorAll('#' + esc(el.id)).length === 1) return '#' + esc(el.id);
    var parts = [];
    var cur = el;
    var depth = 0;
    while (cur && cur.nodeType === 1 && cur !== document.body && depth < 5) {
      var s = cur.tagName.toLowerCase();
      if (cur.id) { parts.unshift('#' + esc(cur.id)); break; }
      var cls = (typeof cur.className === 'string' ? cur.className.trim().split(/\s+/) : [])
        .filter(function (c) { return c && c.length < 30 && !/\d{3,}/.test(c); }).slice(0, 2);
      if (cls.length) s += '.' + cls.map(esc).join('.');
      var p = cur.parentElement;
      if (p) {
        var same = Array.prototype.filter.call(p.children, function (x) { return x.tagName === cur.tagName; });
        if (same.length > 1) s += ':nth-of-type(' + (same.indexOf(cur) + 1) + ')';
      }
      parts.unshift(s);
      cur = cur.parentElement;
      depth++;
    }
    return parts.join(' > ');
  }

  function point(e) {
    var t = (e.changedTouches && e.changedTouches[0]) || (e.touches && e.touches[0]) || e;
    return document.elementFromPoint(t.clientX, t.clientY);
  }

  function show(el) {
    if (!el || el === box || el === tip) return;
    var r = el.getBoundingClientRect();
    box.style.left = r.left + 'px';
    box.style.top = r.top + 'px';
    box.style.width = r.width + 'px';
    box.style.height = r.height + 'px';
    last = el;
  }

  var EVENTS = ['touchstart', 'touchmove', 'touchend', 'click', 'mousedown', 'mouseup',
    'pointerdown', 'pointerup'];

  function handler(e) {
    e.preventDefault();
    e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();
    if (finished) return;
    if (e.type === 'touchstart' || e.type === 'touchmove') show(point(e));
    if (e.type === 'touchend' || e.type === 'click') {
      var el = last || point(e);
      if (!el || el === document.body || el === document.documentElement) return;
      finished = true;
      var sel = selectorFor(el);
      try { FdmMedia.blockElement(location.hostname, sel); } catch (x) { /* ignore */ }
      el.style.setProperty('display', 'none', 'important');
      box.remove();
      tip.remove();
      // Keep swallowing taps for a moment so the synthetic click does not hit the ad.
      setTimeout(function () {
        EVENTS.forEach(function (n) { document.removeEventListener(n, handler, true); });
        window.__fdmPicking = false;
      }, 600);
    }
  }
  EVENTS.forEach(function (n) {
    document.addEventListener(n, handler, { capture: true, passive: false });
  });
})();
