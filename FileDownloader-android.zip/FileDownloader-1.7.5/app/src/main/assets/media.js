(function () {
  if (window.__fdmMedia) return;
  window.__fdmMedia = true;
  function scan() {
    try {
      var els = document.querySelectorAll('video,audio,source');
      for (var i = 0; i < els.length; i++) {
        var s = els[i].currentSrc || els[i].src;
        if (s && /^https?:/.test(s)) FdmMedia.found(s);
      }
    } catch (e) { /* ignore */ }
  }
  setInterval(scan, 1500);
  scan();
})();
