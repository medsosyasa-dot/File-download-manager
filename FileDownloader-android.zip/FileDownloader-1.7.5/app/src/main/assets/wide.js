(function () {
  if (window.__fdmWideInit) return;
  window.__fdmWideInit = true;

  var wideStyle = null;
  var audioStyle = null;
  var badge = null;
  var audioOn = false;
  var ytTimer = null;
  var onYt = /(^|\.)youtube\.com$/.test(location.hostname);

  function styleEl(el, css) {
    if (!el) {
      el = document.createElement('style');
      (document.head || document.documentElement).appendChild(el);
    }
    el.textContent = css;
    return el;
  }

  function forward(msg) {
    var frames = document.querySelectorAll('iframe');
    for (var i = 0; i < frames.length; i++) {
      try { frames[i].contentWindow.postMessage(msg, '*'); } catch (e) { /* ignore */ }
    }
  }

  // "Wide" fills a tall screen with the video by cropping the edges (no stretching).
  function applyWide(on) {
    wideStyle = styleEl(wideStyle, on ? 'video{object-fit:cover!important;}' : '');
    forward({ fdmWide: on });
  }

  function ensureBadge() {
    if (window.top !== window) return;
    if (audioOn && !badge) {
      if (!document.body) {
        document.addEventListener('DOMContentLoaded', ensureBadge);
        return;
      }
      badge = document.createElement('div');
      badge.textContent = '\u266A Mode audio';
      badge.style.cssText = 'position:fixed;z-index:2147483646;left:8px;top:8px;' +
        'padding:4px 10px;border-radius:12px;background:rgba(0,0,0,.65);color:#fff;' +
        'font:12px sans-serif;pointer-events:none;';
      document.body.appendChild(badge);
    } else if (!audioOn && badge) {
      badge.remove();
      badge = null;
    }
  }

  // "Audio only" hides the picture but lets the page keep playing as usual.
  function applyAudio(on) {
    audioOn = on;
    audioStyle = styleEl(audioStyle, on ? 'video{opacity:0!important;}' : '');
    ensureBadge();
    if (onYt) {
      if (on && !ytTimer) {
        // Ask the page's own player for its lowest picture quality (best effort).
        ytTimer = setInterval(function () {
          try {
            var p = document.getElementById('movie_player');
            if (p && p.setPlaybackQualityRange) p.setPlaybackQualityRange('tiny', 'tiny');
          } catch (e) { /* ignore */ }
        }, 2500);
      } else if (!on && ytTimer) {
        clearInterval(ytTimer);
        ytTimer = null;
      }
    }
    forward({ fdmAudio: on });
  }

  window.__fdmSetWide = applyWide;
  window.__fdmSetAudio = applyAudio;
  window.addEventListener('message', function (e) {
    var d = e.data;
    if (d && typeof d === 'object') {
      if ('fdmWide' in d) applyWide(!!d.fdmWide);
      if ('fdmAudio' in d) applyAudio(!!d.fdmAudio);
    }
  });

  function init() {
    try { if (FdmMedia.wide()) applyWide(true); } catch (e) { /* ignore */ }
    try { if (FdmMedia.audioOnly()) applyAudio(true); } catch (e) { /* ignore */ }
  }
  if (document.documentElement) init();
  else document.addEventListener('DOMContentLoaded', init);
})();
