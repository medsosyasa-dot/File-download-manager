(function () {
  if (window.__fdmWideInit) return;
  window.__fdmWideInit = true;
  var style = null;

  // "Wide" fills a tall screen with the video by cropping the edges (no stretching).
  function apply(on) {
    if (!style) {
      style = document.createElement('style');
      (document.head || document.documentElement).appendChild(style);
    }
    style.textContent = on ? 'video{object-fit:cover!important;}' : '';
    var frames = document.querySelectorAll('iframe');
    for (var i = 0; i < frames.length; i++) {
      try { frames[i].contentWindow.postMessage({ fdmWide: on }, '*'); } catch (e) { /* ignore */ }
    }
  }
  window.__fdmSetWide = apply;
  window.addEventListener('message', function (e) {
    if (e.data && typeof e.data === 'object' && 'fdmWide' in e.data) apply(!!e.data.fdmWide);
  });
  try {
    if (FdmMedia.wide()) {
      if (document.documentElement) apply(true);
      else document.addEventListener('DOMContentLoaded', function () { apply(true); });
    }
  } catch (e) { /* ignore */ }
})();
