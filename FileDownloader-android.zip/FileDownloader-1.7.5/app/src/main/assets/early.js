(function () {
  if (window.__fdmDrm) return;
  window.__fdmDrm = true;
  var lastKs = '';
  function report() {
    try { FdmMedia.drm(lastKs || 'DRM'); } catch (e) { /* ignore */ }
  }
  try {
    if (navigator.requestMediaKeySystemAccess) {
      var orig = navigator.requestMediaKeySystemAccess;
      navigator.requestMediaKeySystemAccess = function (ks) {
        lastKs = String(ks);
        return orig.apply(navigator, arguments);
      };
    }
  } catch (e) { /* ignore */ }
  try {
    // Only real use counts: creating a license session (probing support does not).
    var p = window.MediaKeys && window.MediaKeys.prototype;
    if (p && p.createSession) {
      var cs = p.createSession;
      p.createSession = function () {
        report();
        return cs.apply(this, arguments);
      };
    }
  } catch (e) { /* ignore */ }
})();
