(function () {
  if (window.__fdmDrm) return;
  window.__fdmDrm = true;
  var lastKs = '';
  function report() {
    try { FdmMedia.drm(lastKs || 'DRM'); } catch (e) { /* ignore */ }
  }
  try {
    if (navigator.requestMediaKeySystemAccess) {
      var orig = navigator.requestMediaKeySystemAccess;
      navigator.requestMediaKeySystemAccess = function (ks) {
        lastKs = String(ks);
        return orig.apply(navigator, arguments);
      };
    }
  } catch (e) { /* ignore */ }
  try {
    // Only real use counts: creating a license session (probing support does not).
    var p = window.MediaKeys && window.MediaKeys.prototype;
    if (p && p.createSession) {
      var cs = p.createSession;
      p.createSession = function () {
        report();
        return cs.apply(this, arguments);
      };
    }
  } catch (e) { /* ignore */ }
})();

// Hide the "open the app" button and banners on YouTube's mobile site.
(function () {
  if (!/(^|\.)youtube\.com$/.test(location.hostname)) return;
  var PHRASES = ['buka apl', 'buka aplikasi', 'open app', 'open in app', 'open the app',
    'gunakan aplikasi', 'use the app', 'get the app', 'pasang aplikasi', 'install app',
    'unduh aplikasi', 'download the app'];
  var CSS = 'ytm-open-app-banner-renderer,ytm-open-app-button-renderer,' +
    'ytm-mealbar-promo-renderer,[aria-label="Buka Apl"],[aria-label="Open app"]' +
    '{display:none!important;}';
  function addCss() {
    var s = document.createElement('style');
    s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }
  if (document.documentElement) addCss();
  else document.addEventListener('DOMContentLoaded', addCss);

  function sweep() {
    if (!document.body) return;
    var els = document.querySelectorAll('button,a,[role="button"],ytm-button-renderer');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (el.__fdmHidden) continue;
      var t = (el.textContent || '').trim().toLowerCase();
      if (t && t.length < 40 && PHRASES.indexOf(t) !== -1) {
        var target = el.closest('ytm-button-renderer') || el;
        target.style.setProperty('display', 'none', 'important');
        el.__fdmHidden = true;
      }
    }
  }
  setInterval(sweep, 700);
})();
