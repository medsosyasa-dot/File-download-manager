(function () {
  if (window.__fdmSite) return;
  window.__fdmSite = true;

  var cfg = { strict: false, sel: [] };
  try { cfg = JSON.parse(FdmMedia.rules(location.hostname)); } catch (e) { /* ignore */ }

  function addCss(css) {
    var s = document.createElement('style');
    s.textContent = css;
    (document.head || document.documentElement).appendChild(s);
  }
  function applySelectors() {
    // One rule per selector, so a broken selector cannot disable the others.
    var css = '';
    for (var i = 0; i < cfg.sel.length; i++) css += cfg.sel[i] + '{display:none!important;}\n';
    addCss(css);
  }
  if (cfg.sel && cfg.sel.length) {
    if (document.documentElement) applySelectors();
    else document.addEventListener('DOMContentLoaded', applySelectors);
  }

  if (!cfg.strict) return;

  // Strict mode: no pop-ups, and remove invisible full-page layers that steal taps for ads.
  try { window.open = function () { return null; }; } catch (e) { /* ignore */ }

  function sweep() {
    if (!document.body) return;
    var vw = window.innerWidth, vh = window.innerHeight;
    var els = document.body.querySelectorAll('div,iframe,a,span,ins,section');
    var budget = 250;
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (el.__fdmOk) continue;
      if (--budget < 0) break;
      var cs = getComputedStyle(el);
      // Never touch embedded players: only fully see-through frames count as overlays.
      if (el.tagName === 'IFRAME' && !(parseFloat(cs.opacity) < 0.1)) { el.__fdmOk = true; continue; }
      if (cs.position !== 'fixed' && cs.position !== 'absolute') { el.__fdmOk = true; continue; }
      var z = parseInt(cs.zIndex, 10) || 0;
      if (z < 1000) continue;
      var r = el.getBoundingClientRect();
      if (r.width < vw * 0.6 || r.height < vh * 0.6) { el.__fdmOk = true; continue; }
      if (el.tagName === 'VIDEO' || el.querySelector('video')) { el.__fdmOk = true; continue; }
      var empty = (el.textContent || '').trim().length === 0;
      var faint = parseFloat(cs.opacity) < 0.1;
      if (empty || faint) {
        el.remove();
      } else {
        el.__fdmOk = true;
      }
    }
  }
  setInterval(sweep, 1500);
})();
